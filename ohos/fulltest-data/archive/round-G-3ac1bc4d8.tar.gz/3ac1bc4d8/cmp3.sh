#!/bin/sh
identical=0; worse=0; better=0; mixed=0
: > added_real.txt; : > worse_real.txt; : > better_real.txt
while read f; do
  base=$(printf '%s' "$f" | sed 's|^test/||; s|/|__|g')
  l6="repro-jxbit-r6/$base.log"; l7="repro-jxbit-r7/$base.log"
  [ -f "$l6" ] && [ -f "$l7" ] || continue
  grep "^ *(fail)" "$l6" | sed 's/^ *(fail) *//; s/ \[[0-9.]*ms\]$//' | sort -u > pd6.tmp
  grep "^ *(fail)" "$l7" | sed 's/^ *(fail) *//; s/ \[[0-9.]*ms\]$//' | sort -u > pd7.tmp
  a=$(comm -13 pd6.tmp pd7.tmp | wc -l)
  r=$(comm -23 pd6.tmp pd7.tmp | wc -l)
  if [ "$a" = "0" ] && [ "$r" = "0" ]; then identical=$((identical+1));
  elif [ "$a" -gt "$r" ]; then worse=$((worse+1)); echo "$f (+$a/-$r)" >> worse_real.txt; echo "=== $f (+$a/-$r)" >> added_real.txt; comm -13 pd6.tmp pd7.tmp | cut -c1-95 >> added_real.txt;
  elif [ "$r" -gt "$a" ]; then better=$((better+1)); echo "$f (+$a/-$r)" >> better_real.txt;
  else mixed=$((mixed+1)); fi
done < r7-still.txt
echo "RESULT: identical=$identical worse=$worse better=$better mixed(renamed/flaky)=$mixed"
echo "--- worse files ---"; cat worse_real.txt
echo "--- better files ---"; cat better_real.txt
