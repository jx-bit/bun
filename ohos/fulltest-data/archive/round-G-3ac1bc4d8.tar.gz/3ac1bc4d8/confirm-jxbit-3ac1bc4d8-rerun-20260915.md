# 20260915 确认：jx-bit 3ac1bc4d8 失败集复跑（第八次构建）——F2 修复验证通过

> 续 `confirm-jxbit-541794f8d-rerun-20260914.md`。release `ohos-latest` 资产
> 2026-09-15 08:59 UTC 更新（首次预签名发布）。

## 构建验证

| 项 | 值 |
|---|---|
| --revision | **1.4.0-canary.1+3ac1bc4d8** |
| sha256 | raw `a3cc4108…` → 签名后 `82e4f808ca670e3d81babd2235f8af76dbb68af33bbf1c8566e8323d19d851fa` |
| 签名备注 | 资产**自带 .codesign 段**（首次），`ohos-selfsign sign --force` 重签；旧版归档 `bun-ohos-jxbit-541794f8d-signed` |
| platform / F3 | ✅ 保持（openharmony / FAKE-NODE） |
| F1 p6 + multi-run | ✅ 保持（`AAA` 直通 / `a \| AAA` 前缀转发） |
| **F2 p7b 目录路由** | ✅ **修复**：`/index.html` 200 text/html、`/plain.txt` 200 text/plain、`/sub/file.txt` 200 text/plain、`/missing` 404 —— 与 sys-release 完全一致（上轮全 404） |

## 复跑结果（r6-still 口径 160 文件，单次）

| 结果 | 数量 |
|---|---|
| **转 PASS** | **2**（serve-directory-routes=F2、websocket-server） |
| 仍 FAIL | 158 |
| 崩溃 | 0 |

统计备注：`repro-status.txt` 只落了 142 条（复跑收尾被打断，`bake/dev` 14 +
`bundler` 4 等 18 个文件无记录），这 18 个从逐文件 log 的 pass/fail 统计行判定，
**全部为 FAIL**（fail 1–16 例不等）→ 158 = 140 + 18，160 全覆盖。

## 上轮 5 个独有失败去向（vs sys-release 1.4.0_80）

| 文件 | 本轮 | 结论 |
|---|---|---|
| `js/bun/http/serve-directory-routes.test.ts` | **PASS** | **F2 修复落地 ✅** |
| `cli/install/architecture-match.test.ts` | exit=1 | 仍败（install 平台三元组细节） |
| `js/bun/io/bun-write.test.js` | exit=1 | 仍败（io 细节） |
| `integration/expo-app/expo.test.ts` | exit=143（超时） | 仍败（集成环境） |
| `regression/issue/26286.test.ts` | exit=143（超时） | 仍败（单例回归） |

## 八轮迭代修复轨迹（vs sys-release 1.4.0_80）

| 迭代 | jxbit_only 独有 | 成簇项 |
|---|---|---|
| c4323a5d3 | 101 | platform/sql/F1 全部 |
| 0e0fd1559 | 39 | F1 + install |
| 14fdf0d56 | 32 | F1 + install |
| c2459c844 | 26（复跑） | F1 + install |
| 541794f8d | 5 | F2 + 4 散布例 |
| **3ac1bc4d8** | **4** | **无成簇项** |

## 结论

1. **F2（serve 目录路由）修复验证通过**：探针 p7b 四行输出与 sys-release 逐字一致 +
   24 用例文件转 PASS 双重确认。
2. **jx-bit 独有失败收敛至 4 个散布例**，无成簇项；与 sys-release 的差距仅剩
   install 三元组 / io 细节 / expo 集成 / 26286 单例四个逐例项。
3. 三大项（platform、F1 输出捕获、F2 目录路由）+ F3 全部闭环。
4. 建议：跑一次全量轮获取精确用例率（上轮全量 1220 fail 用例，F1+F2 修复后预计
   大幅回落至接近 sys-release 的 637 水位）。

## 逐文件定性：新问题 vs 二进制固有差异（r6 vs r7 fail 集合对比）

对 158 个仍失败文件做 r6(541794f8d) → r7(3ac1bc4d8) 的 fail 用例集合 diff
（指纹去除 `[N ms]` 耗时后缀；`repro-jxbit-r6/` vs `repro-jxbit-r7/` 逐 log 对比）：

| 判定 | 数量 | 说明 |
|---|---|---|
| **fail 集合完全一致** | **151/158** | 逐字相同的失败用例 → **纯延续，非新问题** |
| 净恶化 | 2 | 各净 +1 用例（见下） |
| 净改善 | 3 | 净 −12 用例（bun-install −8、bun-lock −2、resolve-dns −2，全为网络敏感类） |
| 增减相抵 | 2 | 用例名变化的 flaky |

唯二新增 fail 用例（均与 F1/F2 修复域无交集，定性为环境波动）：

| 文件 | 新增用例 | 归因 |
|---|---|---|
| `cli/install/bun-install-registry.test.ts` | `bundledDependencies > (bun.lock) git dependencies` | git 依赖安装（本设备 GitHub 访问受限的常态环境敏感项） |
| `js/bun/util/filesink.test.ts` | `FileSink > file > "😋 Get Emoji…"` | emoji 文件名 IO 边界用例，典型 flaky |

### 结论

1. **不是修复合入新问题**：F1（Bun.$ 输出捕获）/F2（serve 目录路由）修复的代码域
   （shell、multi-run、serve routes）在 158 个失败文件中零新增失败；唯二新增用例
   属 git-install / emoji-filename 环境波动，与修复无因果。
2. **是二进制本身差异**：r6→r7 fail 集合 151/158 逐字一致，证明这些失败是 jx-bit
   基底（1.4.0 canary）与 sys-release 的**固有平台/环境差异**，稳定可复现，非回归。
3. 交叉印证：F2 修复使 serve-directory-routes 24 用例全转 PASS，修复方向无副作用。

### 纵向对比（r3→r7 五轮，158 文件 fail 集合 vs r7）

| 轮 | 覆盖 | fail 集合与 r7 逐字一致 |
|---|---|---|
| r5 | 158/158 | **145（92%）** |
| r4 | 112/158 | 88（79%） |
| r3 | 130/158 | 101（78%） |

r5→r7 不一致的 13 个文件全部定性为**环境波动**：10 个 install/dns/spawn 网络敏感类
（bun-prune 单文件两轮差 110 用例、bun-install 差 11——注册表状态依赖），2 个 http
args 用例名变化型 flaky，1 个 filesink emoji 用例（r4 时代即同样 +1）。无一落在
F1/F2 修复域。r3/r4 的一致率较低（78–79%）恰对应当时 F1 未修、shell 类用例失败
模式不同——**变化的部分对应修复进展，不变的部分是固有差异**。

## 29 项独有失败分类的实测兑现（007d7a07e_only 清单 vs r6/r7 实测）

| 分类 | 项数 | 实测状态 |
|---|---|---|
| ✅ 预期转绿（#41 ESPIPE 16 + #43 openat2 1） | 17 | **17/17 兑现**：ESPIPE 16 项在 r6（541794f8d）全绿；serve-directory-routes 在 r7（3ac1bc4d8）全绿（24 用例） |
| 🔶 #42 待验证 | 2 | architecture-match **仍败**（3ac1bc4d8 不含 #42，待 c7eda0b873 验证）；26207 **r6 即绿**（超额） |
| 🟡 环境轮转 | 7 | **7/7 全绿**：bun-pm-licenses、frozen-lockfile-pruned（r6 绿）+ 补测 5 项全绿（bun-audit 182p、bun-dedupe 76p、bun-workspaces 75p、config-precedence 51p、nested-overrides 144p，`repro-jxbit-gap5/`） |
| ⚪ PARKED | 2 | bun-write、expo 仍败（符合预期） |
| ❓ 待查 | 1 | **26286 仍挂**（exit=143 超时）→ 触发"按 spawn 面深挖" |

**29 项收敛结果：25 绿 / 4 未绿**（architecture-match、bun-write、expo、26286）——
与 r7 报告的 4 个散布例完全一致，两条独立分析路径交叉印证。
注意：bun-audit 等 5 项不在 r6/r7 复跑输入集（r6 输入=14fdf0d56 失败集 ≠ 007d7a07e
独有 29），系本次补测（gap5）首次在修复后构建上验证。

## 数据

复跑日志：`/storage/Users/currentUser/opencode/repro-jxbit-r7/`（160 log）；
r6-vs-r7 对比脚本：`opencode/cmp3.sh`，新增用例明细 `opencode/added_real.txt`；
转 PASS `r7-pass.txt`（2）；仍失败 `r7-still.txt`（158）；
status 142 条 + 18 个 log 判定（详见统计备注）。
