# 20260915 确认：jx-bit 3ac1bc4d8 全量轮（第八个构建，官方 v1.4.0 树）

> 注：本轮下载时确认 release 未再更新——仓库 HEAD 即 3ac1bc4d8（#43 merge commit，
> `c7eda0b873` 为其父提交/上一份分类报告时的旧 tip），资产 updated_at/size 与
> r7 复跑所用完全一致。本全量轮为该构建补全量数据。

## 构建验证

| 项 | 值 |
|---|---|
| --revision | **1.4.0-canary.1+3ac1bc4d8** |
| sha256（签名后） | `82e4f808ca670e3d…` |
| platform / F3 | ✅ openharmony / FAKE-NODE |
| F1 p6 + multi-run | ✅ 保持 |
| F2 p7b 目录路由 | ✅ 保持（200×3 + 404） |

## 全量结果（2001 文件，TMOUT=180 RETRIES=1）

```
Duration: 01:47:09
Files:    2001 | 1830 passed | 171 failed
Cases:    68638 passed | 1052 failed   (用例率 98.49%)
Timeouts: 12 | Crashes: 0
```

## 八轮横向（同树同口径）

| 轮 | binary | Duration | 文件通过 | 用例 fail | 用例率 |
|---|---|---|---|---|---|
| A | sys-release 1.4.0_80 | 02:00:58 | 1816 | 637 | 99.08% |
| B | jx-bit c4323a5d3 | 02:31:39 | 1754 | 943 | 98.63% |
| C | jx-bit 0e0fd1559 | 02:02:33 | 1812 | 1181 | 98.29% |
| D | jx-bit 14fdf0d56 | 01:52:46 | 1808 | 1278 | 98.15% |
| F | jx-bit 007d7a07e | 01:58:46 | 1808 | 1220 | 98.23% |
| **本全量** | **jx-bit 3ac1bc4d8** | **01:47:09** | **1830** | **1052** | **98.49%** |

**里程碑**：文件通过 1830 **历史新高，首次超过 sys-release 基准（1816）**；
fail 用例 1220→1052（F1+F2 修复兑现 −168）；时长 1:47 也为七轮 jx-bit 全量最快。

## 集合运算（vs 轮 A sys-release 185 失败）

| 结果 | 数量 |
|---|---|
| overlap | 151 |
| **仅 3ac1bc4d8 失败** | **15**（007d7a07e 时 29 → 减半） |
| 仅 sys-release 失败 | 34 |

### 15 个独有失败明细

| 归类 | 文件 |
|---|---|
| **确定性待修（根因已定位）** | architecture-match（`["openharmony"]` 期望 true 返回 false——**#42 已包含在本构建中但与此无关**，见下节） |
| PARKED | bun-write（47 中 1）、expo（install 长跑被杀） |
| 环境轮转（gap5 补测刚全绿，本轮又现） | bun-audit、bun-dedupe、frozen-lockfile-pruned、nested-overrides |
| 轮转/新面孔 | inspect、bun-update-transitive、catalogs、pnpm-lock-v9、plugins、sqlite、node-dns、node-http-connect.node.mts |

## architecture-match 根因定位（#42 已含，与本失败无关）

**事实修正**：#42（`fix(ohos): honest deleted-cwd propagation, rlimit clamp, tmpdir
probe, X_OK exec check`）的 merge commit **就是 c7eda0b873**，而本构建 3ac1bc4d8
（#43 merge）包含它——#42 已在 binary 中，但 architecture-match 仍败，证明其原
"#42 加固面"分类不成立。

**真正根因**（`src/install_types/resolver_hooks.rs`，逐文件核实）：
`OperatingSystem` 位标志枚举与 `negatable_names!` 名称映射表**均无 openharmony**
（仅 aix/linux/sunos/win32/darwin/android/freebsd/openbsd），`CURRENT` 的 cfg 分支
也无 OHOS 项。而 C++ 层 `process.platform` 已返回 `"openharmony"`（PR29 修复），
导致 JS→Rust 平台名脱节：`isOperatingSystemMatch(["openharmony"])` 解析失败 → false。

**修复指引（约 3 行）**：
1. 枚举加 `pub(crate) const OPENHARMONY: u16 = 1 << 9;` 并纳入 `ALL_VALUE`
2. `negatable_names!` 表加 `b"openharmony" => OPENHARMONY`
3. `CURRENT` 按其构建三元组的 OHOS 判定方式补分支（若以 linux triple 构建则需对齐
   delivery line 的 OHOS 识别方式，与 `process.platform` 的 "openharmony" 保持一致）
4. 注意 `Architecture` 面无需改动（isArchitectureMatch 全部用例已通过）

## 重点项兑现核对

| 项 | 全量结果 | 结论 |
|---|---|---|
| multi-run（F1，90 用例簇） | **PASS** | F1 保持 ✅ |
| serve-directory-routes（F2，24 用例簇） | **PASS** | F2 保持 ✅（report 中无该文件段落，双重确认） |
| **26286**（r7 复跑 hang） | **PASS** | **间歇性 hang 确认**：非稳定 spawn 缺陷，深挖降级为观察项 |
| architecture-match（#42 已含仍败） | FAIL | **根因另有所在**：OperatingSystem 枚举缺 openharmony（详见上节，3 行修复） |
| 29 项分类中 17 预期转绿 | 全部 PASS | 兑现率 17/17 ✅ |

## 结论

1. **F1/F2 修复在全量口径完全兑现**：90+24 两大用例簇保持全绿，fail 用例 −168。
2. **文件通过首次反超 sys-release**（1830 vs 1816），用例率差收窄至 0.59pp
   （1052 vs 637 fail 用例，差 415，其中 install/dns 环境类占大头）。
3. **jx-bit 独有失败 29→15**：剩余 15 中确定性待修仅 architecture-match，且根因已
   逐文件定位（`resolver_hooks.rs` 的 OperatingSystem 枚举/名称表缺 openharmony，
   约 3 行修复，**与 #42 无关**——#42 已包含在本构建中），其余为环境轮转（4）+
   轮转新面孔（8）+ PARKED 2。
4. **26286 间歇性 hang**：复跑 hang、全量绿 → 非确定性缺陷，按观察项处理。

## 文件清单

| 文件 | 内容 |
|---|---|
| `all-official-report-20260915_211608.txt` | ~~逐文件详细输出~~（2026-09-21 删除——明细已蒸馏进 20260917-round-report；`fulltest-3ac1bc4d8.log` 为该轮地面真相） |
| `fulltest-3ac1bc4d8.log` | runner 进度日志 |
| `lists/fail_3ac1bc4d8.txt`（166） | 失败文件清单（段落头提取口径） |
| `lists/fail_3ac1bc4d8_only.txt`（15） | jx-bit 独有失败 |
| `lists/fail_overlap_both.txt`（151） | 与 sys-release 共同失败 |

提取口径说明：report 段落 = `EXIT_CODE:N`（段尾）+ 下一文件段头；
`EXIT_CODE:0` 计 1830 与汇总 ✅ 完全吻合；fail 提取 166 vs 汇总 171 的差 5 为
段落头匹配边角（嵌套输出行、非标准后缀），不影响集合结论量级。
