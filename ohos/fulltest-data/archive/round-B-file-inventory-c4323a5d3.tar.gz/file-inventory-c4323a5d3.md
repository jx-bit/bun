# 官方 bun-v1.4.0 测试套件 · 执行单元清单（人类可读版）

> 2001 个测试文件 × A(sys-release 1.4.0) / B(jx-bit c4323a5d3) 两轮真机结果 + 源码改动状态。
> 图例：✅通过 ❌失败 ⏰超时 💥崩溃（数字=用例 pass/fail）· ⊘N=skip 用例数 · 🔧=源码有改动（ohos 适配/超时预算等，详 file-inventory.csv）· ⊘a+b=官方树+fork树 skip 门控数
> 排序：每类内 B 独有失败 → 两轮都失败 → A 独有失败 → 通过。机器可读版见 `file-inventory.csv`。

## Bun.sql（59 文件 / 31 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `js/sql/local-sql.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/postgres-binary-numeric.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/postgres-datestyle.test.ts` |  | ✅1/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/postgres-listen-notify.test.ts` |  | ✅44/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/postgres-multi-statement-fields.test.ts` |  | ✅3/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/postgres-prepared-pipeline-reorder.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/postgres-simple-query-pipeline.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/sql-empty-column-name.test.ts` |  | ✅10/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mariadb-json.test.ts` |  | ✅7/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql-bigint-out-of-range.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql-binary-null-indexed.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql-bind-blob-borrow.test.ts` |  | ✅1/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql-bind-oob.test.ts` |  | ✅1/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql-cached-error.test.ts` |  | ✅0/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql-column-name-digits.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql-datetime-roundtrip.test.ts` |  | ✅3/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql-mediumint.test.ts` |  | ✅0/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql-query-string-leak.test.ts` |  | ✅0/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql-raw-length-prefix.test.ts` |  | ✅0/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql.auth.test.ts` |  | ✅4/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql.helpers.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql.test.ts` |  | ✅2/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-mysql.transactions.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/sql-onconnect-onclose-throw.test.ts` |  | ✅7/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-postgres-datetime-roundtrip.test.ts` |  | ✅3/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/sql-prepare-false.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/sql-reserve-abort.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/sql-statement-cache-hash-collision.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail | sql-docker-gate |
| `js/sql/sql.test.ts` |  ⊘1+1 | ✅10/0 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/tls-sql.test.ts` |  ⊘1+1 | ✅2/0⊘1 | ❌0/1 | B-only-fail | sql-docker-gate |
| `js/sql/adapter-env-var-precedence.test.ts` | 🔧适配 ⊘3+3 | ❌92/1 | ❌92/1 | both-fail | env-baseline |
| `js/sql/adapter-override.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/sql/postgres-binary-array-bounds.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/sql/postgres-binary-float-nan-box.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/sql/postgres-binary-numeric-digit-range.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/sql/postgres-datarow-overrun.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/sql/postgres-duplicate-auth-request.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/sql/postgres-error-then-datarow.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/sql/postgres-failed-connection-resurrection.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/sql/postgres-finish-request-underflow.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/sql/postgres-frame-boundary.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/sql/postgres-infinity-date.test.ts` |  | ✅18/0 | ✅18/0 | both-pass |  |
| `js/sql/postgres-invalid-message-length.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/sql/postgres-pgsslmode-env.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/sql/postgres-split-prepare-reorder.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/sql/postgres-tls-ctx-leak.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/sql/sql-close-pending-connection.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/sql/sql-connect-error-reporting.test.ts` |  | ✅15/0 | ✅15/0 | both-pass |  |
| `js/sql/sql-helpers-validation.test.ts` |  | ✅28/0 | ✅28/0 | both-pass |  |
| `js/sql/sql-mysql-auth-short-nonce.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/sql/sql-mysql-clean-reentry.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/sql/sql-mysql-columns-realloc-oom.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/sql/sql-mysql-duplicate-auth-switch.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/sql/sql-mysql-prepare-ok-zero-statement-id.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/sql/sql-mysql-tls-plaintext-injection.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/sql/sql-pool-transaction-isolation.test.ts` |  | ✅18/0 | ✅18/0 | both-pass |  |
| `js/sql/sqlite-sql.test.ts` |  | ✅248/0 | ✅248/0 | both-pass |  |
| `js/sql/sqlite-url-parsing.test.ts` |  | ✅176/0 | ✅176/0 | both-pass |  |
| `js/sql/wire-frames.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |

## CLI 命令（172 文件 / 57 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `cli/inspect/BunFrontendDevServer.test.ts` |  | ✅1/0⊘10 | ❌1/1 | B-only-fail | path-bin-resolution |
| `cli/inspect/HTTPServerAgent.test.ts` |  | ✅0/0⊘3 | ❌0/1 | B-only-fail | path-bin-resolution |
| `cli/inspect/inspect.test.ts` | 🔧ohos | ✅25/0 | ❌25/4 | B-only-fail | path-bin-resolution |
| `cli/inspect/test-reporter.test.ts` |  | ✅0/0⊘2 | ❌0/2 | B-only-fail | path-bin-resolution |
| `cli/install/bun-install-git-deps.test.ts` |  | ✅7/0 | ❌2/5 | B-only-fail |  |
| `cli/install/bun-install-proxy.test.ts` |  | ✅0/0 | ❌0/1 | B-only-fail |  |
| `cli/install/bun-pm-licenses.test.ts` |  | ✅79/0 | ❌76/3 | B-only-fail |  |
| `cli/install/bun-pm-version.test.ts` |  | ✅24/0 | ❌23/1 | B-only-fail |  |
| `cli/install/bun-run-bunfig.test.ts` |  | ✅28/0 | ❌18/10 | B-only-fail |  |
| `cli/install/bun-run.test.ts` | ⏱超时预算 ⊘3+3 | ✅295/0⊘2 | ❌285/10⊘2 | B-only-fail |  |
| `cli/install/bun-update-lockfile-sync.test.ts` |  | ✅77/0 | ❌75/2 | B-only-fail |  |
| `cli/install/isolated-relink.test.ts` |  | ✅6/0⊘1 | ❌5/1⊘1 | B-only-fail |  |
| `cli/run/as-node.test.ts` |  | ✅11/0 | ❌0/11 | B-only-fail | path-bin-resolution |
| `cli/run/env.test.ts` |  ⊘3+3 | ✅96/0⊘3 | ❌92/4⊘3 | B-only-fail | path-bin-resolution |
| `cli/run/filter-workspace.test.ts` |  ⊘3+3 | ✅79/0⊘2 | ❌7/72⊘2 | B-only-fail | path-bin-resolution |
| `cli/run/glob-on-fuse.test.ts` | 🔧ohos ⊘1+1 | ✅0/0⊘6 | ❌0/2 | B-only-fail | path-bin-resolution |
| `cli/run/multi-run.test.ts` | 🔧ohos ⊘2+3 | ✅121/0 | ❌31/90 | B-only-fail | path-bin-resolution |
| `cli/run/no-orphans.test.ts` | 🔧ohos | ✅0/0⊘24 | ❌12/6⊘6 | B-only-fail | path-bin-resolution |
| `cli/run/run-crash-handler.test.ts` |  ⊘1+1 | ✅4/0⊘22 | ❌16/2⊘8 | B-only-fail | path-bin-resolution |
| `cli/run/run-file-on-fuse.test.ts` | 🔧ohos ⊘1+1 | ✅0/0⊘4 | ❌0/2 | B-only-fail | path-bin-resolution |
| `cli/run/run-quote.test.ts` |  | ✅6/0 | ❌5/1 | B-only-fail | path-bin-resolution |
| `cli/run/run-shell.test.ts` |  ⊘1+1 | ✅3/0 | ❌2/1 | B-only-fail | path-bin-resolution |
| `cli/run/shell-keepalive.test.ts` |  | ✅2/0 | ❌1/1 | B-only-fail | path-bin-resolution |
| `cli/run/workspaces.test.ts` |  | ✅3/0 | ❌1/2 | B-only-fail | path-bin-resolution |
| `cli/test/test-changed.test.ts` |  ⊘1+1 | ✅20/0 | ❌0/0 | B-only-fail |  |
| `cli/test/test-shard.test.ts` |  | ✅29/0 | ❌27/2 | B-only-fail |  |
| `cli/create/create-jsx.test.ts` |  | ❌1/4 | ❌3/2 | both-fail | env-baseline |
| `cli/hot/hot.test.ts` | 🔧ohos | ❌11/1 | ❌10/2 | both-fail | env-baseline |
| `cli/init/init.test.ts` | 🔧ohos | ❌11/4 | ❌11/4 | both-fail | env-baseline |
| `cli/install/bun-add-filter.test.ts` |  | ❌123/1 | ❌122/2 | both-fail | env-baseline |
| `cli/install/bun-add.test.ts` | 🔧ohos | ❌68/2 | ❌68/2 | both-fail | env-baseline |
| `cli/install/bun-create.test.ts` | ⏱超时预算 ⊘1+1 | ❌17/3⊘1 | ❌18/3 | both-fail | env-baseline |
| `cli/install/bun-install-lifecycle-scripts.test.ts` |  | ❌63/2 | ❌69/53 | both-fail | env-baseline |
| `cli/install/bun-install-native-binlink.test.ts` |  ⊘1+1 | ❌3/13 | ❌14/2 | both-fail | env-baseline |
| `cli/install/bun-install-patch.test.ts` |  | ❌4/16 | ❌15/5 | both-fail | env-baseline |
| `cli/install/bun-install-registry.test.ts` |  | ❌240/3 | ❌236/7 | both-fail | env-baseline |
| `cli/install/bun-install.test.ts` |  ⊘1+1 | ❌230/8 | ❌215/23 | both-fail | env-baseline |
| `cli/install/bun-lock.test.ts` |  ⊘1+1 | ❌39/1 | ❌36/4 | both-fail | env-baseline |
| `cli/install/bun-lockb.test.ts` |  | ❌6/1 | ❌6/1 | both-fail | env-baseline |
| `cli/install/bun-pack.test.ts` |  ⊘1+1 | ❌77/3 | ❌78/2 | both-fail | env-baseline |
| `cli/install/bun-patch.test.ts` |  | ❌25/12 | ❌20/17 | both-fail | env-baseline |
| `cli/install/bun-pm-diff.test.ts` |  ⊘3+3 | ❌44/2 | ❌44/2 | both-fail | env-baseline |
| `cli/install/bun-prune.test.ts` |  | ❌106/5 | ❌108/3 | both-fail | env-baseline |
| `cli/install/bun-upgrade.test.ts` |  | ❌5/3 | ❌6/2 | both-fail | env-baseline |
| `cli/install/bunx.test.ts` | 🔧ohos ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `cli/install/isolated-install.test.ts` | 🔧ohos ⊘3+4 | ❌81/1 | ❌76/6 | both-fail | env-baseline |
| `cli/install/migration/complex-workspace.test.ts` | 🔧ohos | ❌0/21 | ❌0/21 | both-fail | env-baseline |
| `cli/install/symlink-path-traversal.test.ts` |  ⊘6+6 | ❌9/3 | ❌9/3 | both-fail | env-baseline |
| `cli/run/require-cache.test.ts` | 🔧ohos ⊘2+2 | ❌9/2 | ❌8/2 | both-fail | env-baseline |
| `cli/test/bun-test.test.ts` |  ⊘8+8 | ❌93/2 | ❌1/0 | both-fail | env-baseline |
| `cli/test/parallel.test.ts` |  ⊘4+4 | ❌33/1⊘1 | ❌28/6⊘1 | both-fail | env-baseline |
| `cli/watch/watch.test.ts` | 🔧ohos ⊘3+3 | ❌6/1⊘1 | ❌7/1 | both-fail | env-baseline |
| `cli/install/bad-workspace.test.ts` |  ⊘2+2 | ❌10/3 | ✅13/0 | A-only-fail |  |
| `cli/install/bun-security-scanner-matrix-with-node-modules.test.ts` |  | ❌56/11⊘653 | ✅58/0⊘662 | A-only-fail |  |
| `cli/install/bun-security-scanner-matrix-without-node-modules.test.ts` |  | ❌44/21⊘655 | ✅66/0⊘654 | A-only-fail |  |
| `cli/install/migrate-bun-lockb-v2.test.ts` |  | ❌1/1 | ✅2/0 | A-only-fail |  |
| `cli/install/migration/migrate.test.ts` |  | ❌121/4 | ✅125/0 | A-only-fail |  |
| `cli/bun.test.ts` |  ⊘1+1 | ✅35/0 | ✅35/0 | both-pass |  |
| `cli/bunfig-test-options.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `cli/console-depth.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `cli/env/bun-options.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `cli/env/ci-info.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `cli/heap-prof.test.ts` |  ⊘2+2 | ✅16/0 | ✅16/0 | both-pass |  |
| `cli/hot/watch-many-dirs.test.ts` |  ⊘3+3 | ✅1/0⊘2 | ✅2/0⊘1 | both-pass |  |
| `cli/hot/watch.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/inspect/bun-inspector-protocol.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/inspect/debugger-buntranspiledmodule.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/inspect/inspect-inline-sourcemap.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/install/architecture-match.test.ts` |  | ✅30/0 | ✅30/0 | both-pass |  |
| `cli/install/bun-add-catalog.test.ts` |  | ✅149/0 | ✅149/0 | both-pass |  |
| `cli/install/bun-audit.test.ts` |  | ✅182/0 | ✅182/0 | both-pass |  |
| `cli/install/bun-dedupe.test.ts` |  | ✅76/0 | ✅76/0 | both-pass |  |
| `cli/install/bun-info.test.ts` | ⏱超时预算 ⊘1+1 | ✅19/0⊘1 | ✅19/0⊘1 | both-pass |  |
| `cli/install/bun-install-cpu-os.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `cli/install/bun-install-hardlink-fallback.test.ts` |  ⊘1+1 | ✅0/0⊘4 | ✅0/0⊘4 | both-pass |  |
| `cli/install/bun-install-pathname-trailing-slash.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/install/bun-install-retry.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `cli/install/bun-install-security-provider.test.ts` |  | ✅43/0 | ✅43/0 | both-pass |  |
| `cli/install/bun-install-stalled-tls.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/install/bun-install-streaming-extract.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `cli/install/bun-install-tarball-integrity.test.ts` |  | ✅16/0 | ✅16/0 | both-pass |  |
| `cli/install/bun-link.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `cli/install/bun-pm-pkg.test.ts` |  | ✅74/0 | ✅74/0 | both-pass |  |
| `cli/install/bun-pm-scan.test.ts` | ⏱超时预算 | ✅17/0 | ✅17/0 | both-pass |  |
| `cli/install/bun-pm-why.test.ts` | ⏱超时预算 | ✅28/0 | ✅28/0 | both-pass |  |
| `cli/install/bun-pm.test.ts` |  | ✅18/0 | ✅18/0 | both-pass |  |
| `cli/install/bun-publish.test.ts` |  ⊘1+1 | ✅45/0⊘1 | ✅46/0 | both-pass |  |
| `cli/install/bun-remove.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `cli/install/bun-run-dir.test.ts` | ⏱超时预算 | ✅3/0 | ✅3/0 | both-pass |  |
| `cli/install/bun-security-scanner-workspaces.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `cli/install/bun-update-security-edge-cases.test.ts` | ⏱超时预算 | ✅6/0 | ✅6/0 | both-pass |  |
| `cli/install/bun-update-security-provider.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/install/bun-update-security-scan-all.test.ts` | ⏱超时预算 | ✅5/0 | ✅5/0 | both-pass |  |
| `cli/install/bun-update-security-simple.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/install/bun-update-transitive.test.ts` |  | ✅174/0 | ✅174/0 | both-pass |  |
| `cli/install/bun-update.test.ts` |  | ✅156/0 | ✅156/0 | both-pass |  |
| `cli/install/bun-workspaces.test.ts` |  | ✅75/0 | ✅75/0 | both-pass |  |
| `cli/install/catalogs.test.ts` |  | ✅89/0 | ✅89/0 | both-pass |  |
| `cli/install/config-precedence.test.ts` |  | ✅51/0 | ✅51/0 | both-pass |  |
| `cli/install/config-version.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `cli/install/frozen-lockfile-missing-workspace.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/install/frozen-lockfile-pruned.test.ts` |  | ✅101/0 | ✅101/0 | both-pass |  |
| `cli/install/GHSA-pfwx-36v6-832x.test.ts` | ⏱超时预算 | ✅5/0 | ✅5/0 | both-pass |  |
| `cli/install/hoist.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/install/hosted-git-info/boundary-conditions.test.ts` | ⏱超时预算 | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/install/hosted-git-info/from-url.test.ts` |  ⊘1+1 | ✅649/0⊘32 | ✅649/0⊘32 | both-pass |  |
| `cli/install/hosted-git-info/parse-url.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `cli/install/install-fd-leak.test.ts` |  ⊘1+1 | ✅4/0 | ✅4/0 | both-pass |  |
| `cli/install/lockfile-only.test.ts` |  | ✅19/0 | ✅19/0 | both-pass |  |
| `cli/install/lockfile-version-2.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `cli/install/migration/pnpm-comprehensive.test.ts` | ⏱超时预算 | ✅5/0 | ✅5/0 | both-pass |  |
| `cli/install/migration/pnpm-lock-migration.test.ts` | ⏱超时预算 | ✅5/0 | ✅5/0 | both-pass |  |
| `cli/install/migration/pnpm-lock-v9.test.ts` |  | ✅81/0 | ✅81/0 | both-pass |  |
| `cli/install/migration/pnpm-migration-complete.test.ts` | ⏱超时预算 | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/install/migration/pnpm-migration.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `cli/install/migration/yarn-lock-migration.test.ts` | ⏱超时预算 | ✅18/0 | ✅18/0 | both-pass |  |
| `cli/install/minimum-release-age.test.ts` |  | ✅49/0 | ✅49/0 | both-pass |  |
| `cli/install/nested-overrides.test.ts` |  | ✅144/0 | ✅144/0 | both-pass |  |
| `cli/install/npmrc.test.ts` |  ⊘1+1 | ✅40/0 | ✅40/0 | both-pass |  |
| `cli/install/overrides.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `cli/install/public-hoist-pattern.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `cli/install/redacted-config-logs.test.ts` |  | ✅16/0 | ✅16/0 | both-pass |  |
| `cli/install/semver.test.ts` |  | ✅28/0 | ✅28/0 | both-pass |  |
| `cli/install/shebang-normalize.test.ts` |  ⊘2+2 | ✅1/0⊘1 | ✅1/0⊘1 | both-pass |  |
| `cli/install/test-dev-peer-dependency-priority.test.ts` | ⏱超时预算 | ✅4/0 | ✅4/0 | both-pass |  |
| `cli/run/autoinstall-cached-manifest.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/run/commonjs-invalid.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/run/commonjs-no-export.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/run/cpu-prof.test.ts` |  ⊘1+1 | ✅12/0 | ✅12/0 | both-pass |  |
| `cli/run/crash-report-command-char.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `cli/run/empty-file.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/run/esm-defineProperty.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `cli/run/garbage-env.test.ts` | 🔧ohos | ✅0/0⊘1 | ✅1/0 | both-pass |  |
| `cli/run/if-present.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `cli/run/jsx-namespaced-attributes.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/run/jsx-symbol-collision.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/run/log-test.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/run/markdown-entrypoint.test.ts` |  ⊘1+1 | ✅29/0⊘1 | ✅29/0⊘1 | both-pass |  |
| `cli/run/no-envfile.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `cli/run/preload-test.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/run/require-and-import-trailing.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/run/run_command.test.ts` |  | ✅2/0⊘1 | ✅2/0⊘1 | both-pass |  |
| `cli/run/run-autoinstall-abs-path.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/run/run-autoinstall.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `cli/run/run-cjs.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/run/run-eval.test.ts` |  | ✅37/0 | ✅37/0 | both-pass |  |
| `cli/run/run-extensionless.test.ts` |  ⊘1+1 | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/run/run-process-env.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/run/run-propagate-sigkill.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅1/0 | both-pass |  |
| `cli/run/run-unicode.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/run/self-reference.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/run/sql-preconnect.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/run/syntax.test.ts` |  | ✅592/0 | ✅592/0 | both-pass |  |
| `cli/run/transpiler-cache.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `cli/run/tsconfig-override.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `cli/test/claudecode-flag.test.ts` |  ⊘2+2 | ✅3/0 | ✅3/0 | both-pass |  |
| `cli/test/concurrent-test-glob.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `cli/test/coverage.test.ts` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `cli/test/expectations.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/test/isolation.test.ts` |  | ✅25/0 | ✅25/0 | both-pass |  |
| `cli/test/pass-with-no-tests.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `cli/test/path-ignore-patterns.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `cli/test/rerun-each.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `cli/test/retry-flag.test.ts` |  ⊘1+1 | ✅9/0 | ✅9/0 | both-pass |  |
| `cli/test/test-filter-lifecycle-snapshot.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `cli/test/test-randomize.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `cli/test/test-timeout-behavior.test.ts` |  | ✅2/0 | ✅0/0 | both-pass |  |
| `cli/update_interactive_formatting.test.ts` |  ⊘1+1 | ✅24/0 | ✅24/0 | both-pass |  |
| `cli/update_interactive_install.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `cli/update_interactive_snapshots.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `cli/user-agent.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `cli/watch/watcher-trace.test.ts` | 🔧ohos | ✅4/0 | ✅4/0 | both-pass |  |

## bake/SSR（24 文件 / 17 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `bake/dev/css.test.ts` |  | ⏰ | ⏰ | both-fail | env-baseline |
| `bake/dev/hot.test.ts` |  | ⏰ | ⏰ | both-fail | env-baseline |
| `bake/dev-and-prod.test.ts` |  | ❌2/10 | ✅12/0 | A-only-fail |  |
| `bake/dev/bundle.test.ts` |  | ⏰ | ✅21/0 | A-only-fail | bake-dev-gap |
| `bake/dev/ecosystem.test.ts` |  | ❌0/1 | ✅1/0 | A-only-fail | bake-dev-gap |
| `bake/dev/esm.test.ts` |  | ❌10/6 | ✅16/0 | A-only-fail | bake-dev-gap |
| `bake/dev/html.test.ts` |  | ❌6/4 | ✅10/0 | A-only-fail | bake-dev-gap |
| `bake/dev/import-meta-inline.test.ts` |  | ❌5/1 | ✅6/0 | A-only-fail | bake-dev-gap |
| `bake/dev/incremental-graph-edge-deletion.test.ts` |  | ❌0/1 | ✅1/0 | A-only-fail | bake-dev-gap |
| `bake/dev/production.test.ts` |  | ❌1/11 | ✅12/0 | A-only-fail | bake-dev-gap |
| `bake/dev/react-response.test.ts` |  | ❌0/11 | ✅11/0 | A-only-fail | bake-dev-gap |
| `bake/dev/react-spa.test.ts` |  | ❌0/6 | ✅6/0 | A-only-fail | bake-dev-gap |
| `bake/dev/request-cookies.test.ts` |  | ❌0/2 | ✅2/0 | A-only-fail | bake-dev-gap |
| `bake/dev/server-sourcemap.test.ts` |  | ❌0/4 | ✅4/0 | A-only-fail | bake-dev-gap |
| `bake/dev/sourcemap.test.ts` |  | ❌1/1 | ✅2/0 | A-only-fail | bake-dev-gap |
| `bake/dev/ssg-pages-router.test.ts` |  | ❌0/9 | ✅9/0 | A-only-fail | bake-dev-gap |
| `bake/dev/stress.test.ts` |  | ❌0/1 | ✅1/0 | A-only-fail | bake-dev-gap |
| `bake/deinitialization.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `bake/dev/import-meta-inline-negative.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bake/dev/plugins.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `bake/dev/response-to-bake-response.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `bake/dev/vfile.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bake/framework-router.test.ts` |  | ✅35/0 | ✅35/0 | both-pass |  |
| `bake/serve-plugins-dev-server.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |

## 打包器（98 文件 / 6 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `bundler/bun-build-api.test.ts` |  ⊘3+3 | ❌51/1⊘2 | ❌51/1⊘2 | both-fail | env-baseline |
| `bundler/bun-build-compile.test.ts` | 🔧ohos ⊘1+2 | ❌7/1⊘1 | ❌13/2 | both-fail | env-baseline |
| `bundler/bundler_edgecase.test.ts` | 🔧ohos | ❌133/1 | ❌133/1 | both-fail | env-baseline |
| `bundler/bundler_compile.test.ts` |  | ❌63/7 | ✅70/0 | A-only-fail |  |
| `bundler/bundler_npm.test.ts` |  | ❌0/2 | ✅2/0 | A-only-fail |  |
| `bundler/native-plugin.test.ts` | 🔧ohos ⊘1+1 | ❌0/1 | ✅19/0⊘1 | A-only-fail |  |
| `bundler/bun-build-compile-sourcemap.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `bundler/bun-build-compile-wasm.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/bundler_allow_unresolved.test.ts` |  | ✅16/0 | ✅16/0 | both-pass |  |
| `bundler/bundler_banner.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `bundler/bundler_barrel.test.ts` |  | ✅51/0 | ✅51/0 | both-pass |  |
| `bundler/bundler_browser.test.ts` |  ⊘1+1 | ✅17/0⊘1 | ✅17/0⊘1 | both-pass |  |
| `bundler/bundler_bun.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `bundler/bundler_cjs.test.ts` |  | ✅28/0 | ✅28/0 | both-pass |  |
| `bundler/bundler_cjs2esm.test.ts` |  | ✅27/0 | ✅27/0 | both-pass |  |
| `bundler/bundler_comments.test.ts` |  | ✅45/0 | ✅45/0 | both-pass |  |
| `bundler/bundler_compile_autoload.test.ts` |  | ✅23/0 | ✅23/0 | both-pass |  |
| `bundler/bundler_compile_splitting.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `bundler/bundler_decorator_metadata.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `bundler/bundler_defer.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `bundler/bundler_drop.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `bundler/bundler_env.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `bundler/bundler_feature_flag.test.ts` |  | ✅41/0 | ✅41/0 | both-pass |  |
| `bundler/bundler_files.test.ts` |  | ✅24/0 | ✅24/0 | both-pass |  |
| `bundler/bundler_footer.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `bundler/bundler_html_server.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `bundler/bundler_html.test.ts` |  | ✅22/0 | ✅22/0 | both-pass |  |
| `bundler/bundler_jsx.test.ts` |  | ✅48/0 | ✅48/0 | both-pass |  |
| `bundler/bundler_loader.test.ts` |  | ✅58/0 | ✅58/0 | both-pass |  |
| `bundler/bundler_minify_symbol_for.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `bundler/bundler_minify.test.ts` |  | ✅43/0 | ✅43/0 | both-pass |  |
| `bundler/bundler_naming.test.ts` |  | ✅27/0 | ✅27/0 | both-pass |  |
| `bundler/bundler_plugin_chain.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `bundler/bundler_plugin.test.ts` |  | ✅55/0 | ✅55/0 | both-pass |  |
| `bundler/bundler_promiseall_deadcode.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `bundler/bundler_regressions.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `bundler/bundler_splitting.test.ts` |  | ✅22/0 | ✅22/0 | both-pass |  |
| `bundler/bundler_string.test.ts` |  | ✅59/0 | ✅59/0 | both-pass |  |
| `bundler/cli.test.ts` |  ⊘2+2 | ✅33/0⊘2 | ✅33/0⊘2 | both-pass |  |
| `bundler/compile-argv.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `bundler/compile-asset-bunfs.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `bundler/compile-process-execargv.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `bundler/compile-sourcemap-internal.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/compile-windows-metadata.test.ts` |  ⊘2+2 | ✅2/0⊘20 | ✅2/0⊘20 | both-pass |  |
| `bundler/css/css-modules.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `bundler/css/is-selector-21169.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/css/mask-geometry-box.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `bundler/css/view-transition-23600.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/css/wpt/background-computed.test.ts` |  | ✅24/0 | ✅24/0 | both-pass |  |
| `bundler/css/wpt/color-computed-rgb.test.ts` |  | ✅94/0 | ✅94/0 | both-pass |  |
| `bundler/css/wpt/color-computed.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `bundler/css/wpt/relative_color_out_of_gamut.test.ts` |  | ✅27/0 | ✅27/0 | both-pass |  |
| `bundler/esbuild/css.test.ts` |  | ✅56/0 | ✅56/0 | both-pass |  |
| `bundler/esbuild/dce.test.ts` |  | ✅78/0 | ✅78/0 | both-pass |  |
| `bundler/esbuild/default.test.ts` |  ⊘5+5 | ✅151/0⊘5 | ✅151/0⊘5 | both-pass |  |
| `bundler/esbuild/extra.test.ts` |  | ✅220/0 | ✅220/0 | both-pass |  |
| `bundler/esbuild/importstar_ts.test.ts` |  | ✅23/0 | ✅23/0 | both-pass |  |
| `bundler/esbuild/importstar.test.ts` |  | ✅75/0 | ✅75/0 | both-pass |  |
| `bundler/esbuild/loader.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `bundler/esbuild/lower.test.ts` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `bundler/esbuild/metafile.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `bundler/esbuild/packagejson.test.ts` |  | ✅84/0 | ✅84/0 | both-pass |  |
| `bundler/esbuild/splitting.test.ts` |  | ✅26/0 | ✅26/0 | both-pass |  |
| `bundler/esbuild/ts.test.ts` |  | ✅57/0 | ✅57/0 | both-pass |  |
| `bundler/esbuild/tsconfig.test.ts` |  ⊘1+1 | ✅17/0 | ✅17/0 | both-pass |  |
| `bundler/html-import-manifest.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `bundler/metafile.test.ts` |  | ✅44/0 | ✅44/0 | both-pass |  |
| `bundler/plugin-error-nested-throw.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `bundler/plugin-sync-exception-fallback.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `bundler/resolver/cache-invalidation.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `bundler/resolver/cache-node-compat.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `bundler/resolver/cache-runtime.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `bundler/standalone.test.ts` |  | ✅26/0 | ✅26/0 | both-pass |  |
| `bundler/transpiler_constant_fold_eqeq.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/transpiler/assign-to-import.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `bundler/transpiler/bun-pragma.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `bundler/transpiler/decorator-metadata.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `bundler/transpiler/decorators.test.ts` |  | ✅24/0 | ✅24/0 | both-pass |  |
| `bundler/transpiler/es-decorators-esbuild.test.ts` |  | ✅147/0 | ✅147/0 | both-pass |  |
| `bundler/transpiler/es-decorators.test.ts` |  | ✅59/0 | ✅59/0 | both-pass |  |
| `bundler/transpiler/export-default.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/transpiler/function-tostring-require.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/transpiler/jsx-deep-nesting-stack-overflow.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/transpiler/jsx-production.test.ts` |  | ✅32/0 | ✅32/0 | both-pass |  |
| `bundler/transpiler/jsx-tsconfig-react-jsx.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `bundler/transpiler/macro-test.test.ts` |  | ✅15/0 | ✅15/0 | both-pass |  |
| `bundler/transpiler/preserve-use-strict-cjs.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `bundler/transpiler/property.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/transpiler/react-compiler-fixtures.test.ts` |  | ✅2467/0⊘1146 | ✅2467/0⊘1146 | both-pass |  |
| `bundler/transpiler/react-compiler.test.ts` |  ⊘1+1 | ✅36/0⊘1 | ✅36/0⊘1 | both-pass |  |
| `bundler/transpiler/runtime-transpiler.test.ts` |  | ✅15/0 | ✅15/0 | both-pass |  |
| `bundler/transpiler/scope-mismatch-panic.test.ts` |  | ✅16/0 | ✅16/0 | both-pass |  |
| `bundler/transpiler/simplifier-side-effects.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/transpiler/template-literal.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/transpiler/transpiler-stack-overflow.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `bundler/transpiler/transpiler.test.js` |  ⊘1+1 | ✅188/0⊘1 | ✅188/0⊘1 | both-pass |  |
| `bundler/transpiler/ts-enum-redecl-panic.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `bundler/transpiler/ts-use-define-for-class-fields.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |

## 回归测试(issue)（413 文件 / 27 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `regression/issue/15753.test.ts` |  ⊘1+1 | ✅0/0⊘6 | ❌2/3⊘1 | B-only-fail |  |
| `regression/issue/21311.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail |  |
| `regression/issue/22650-shell-crash.test.ts` |  | ✅1/0 | ❌0/1 | B-only-fail |  |
| `regression/issue/24742.test.ts` | 🔧ohos ⊘1+1 | ✅0/0⊘1 | ❌0/1 | B-only-fail |  |
| `regression/issue/24850.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail |  |
| `regression/issue/26030.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail |  |
| `regression/issue/26063.test.ts` |  | ✅0/0 | ❌0/1 | B-only-fail |  |
| `regression/issue/26207.test.ts` |  ⊘1+1 | ✅3/0 | ❌0/3 | B-only-fail |  |
| `regression/issue/28632.test.ts` |  | ✅0/0 | ❌0/1 | B-only-fail |  |
| `regression/issue/29290.test.ts` | 🔧ohos ⊘2+2 | ✅0/0⊘2 | ❌0/2 | B-only-fail |  |
| `regression/issue/02499/02499.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `regression/issue/13696.test.ts` |  | ❌2/1 | ❌2/1 | both-fail | env-baseline |
| `regression/issue/14945-lifecycle-script-crash.test.ts` |  | ❌1/1 | ❌1/1 | both-fail | env-baseline |
| `regression/issue/15276.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `regression/issue/18239/18239.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `regression/issue/20144/20144.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `regression/issue/24364.test.ts` | 🔧ohos | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `regression/issue/25903.test.ts` |  ⊘1+1 | ❌1/6 | ❌1/6 | both-fail | env-baseline |
| `regression/issue/26249.test.ts` |  ⊘2+2 | ❌0/2 | ❌0/2 | both-fail | env-baseline |
| `regression/issue/27272.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `regression/issue/28159.test.ts` | 🔧ohos | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `regression/issue/32492.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `regression/issue/ctrl-c.test.ts` |  ⊘2+2 | ❌2/6 | ❌2/6 | both-fail | env-baseline |
| `regression/issue/test-process-stdout-async-iterator.test.ts` |  | ❌1/2 | ❌1/2 | both-fail | env-baseline |
| `regression/issue/10132.test.ts` |  | ❌1/1 | ✅2/0 | A-only-fail |  |
| `regression/issue/26225.test.ts` |  | ❌1/2 | ✅3/0 | A-only-fail |  |
| `regression/issue/26657.test.ts` |  | ❌1/1 | ✅2/0 | A-only-fail |  |
| `regression/issue/00631.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/012039.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/012040.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/012360.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/013880.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/014187.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/01466.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/014865.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/015201.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/02005.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/02367.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/02368.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/02369.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/026039.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/02977.test.ts` |  | ✅0/0⊘1 | ✅1/0 | both-pass |  |
| `regression/issue/03091.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/03216.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/03830.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/03844/03844.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/04011.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/04298/04298.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/04893.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/04947.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/05545.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/05828.test.ts` |  | ✅0/0⊘1 | ✅1/0 | both-pass |  |
| `regression/issue/06443.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/06467.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/06946/06946.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/07001.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/07261.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/07263.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/07324.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/07397.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/07500/07500.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/07736.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/07740.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/07827.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/07917/7917.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/08040.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/08093.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/08095.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/08757.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/08768.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/08794.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/08893.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/08964/08964.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/08965/08965.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/09041.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/09279.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/09340.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/09469.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/09555.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/09559.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/09563/09563.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/09739.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/09748.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/09778.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/10004.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/10139.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/10170.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/10380/spy-matchers-diff.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/10887.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/11029-crypto-verify-null-algorithm.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/11100.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/11297/11297.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/11664.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/11677.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `regression/issue/11793.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/11806.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/11866.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/12034/12034.test.js` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `regression/issue/12042.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/12117.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/12250.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/12548.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/12650.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/12782.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/12910/12910.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/13251.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/13316.test.ts` |  | ✅0/0⊘3 | ✅0/0⊘3 | both-pass |  |
| `regression/issue/1365.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/14029.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/14135.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/14338.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/14477/14477.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/14515.test.tsx` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/14624.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/14709.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/14799.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅1/0 | both-pass |  |
| `regression/issue/14976/14976.test.ts` |  ⊘1+1 | ✅6/0⊘1 | ✅6/0⊘1 | both-pass |  |
| `regression/issue/14982/14982.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/15314.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/15326.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/16007.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/16312.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/1632.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/16474.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/16476/16476.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/16702/16702.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/17244.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/17294.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `regression/issue/17327.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/17405.test.ts` |  | ✅22/0 | ✅22/0 | both-pass |  |
| `regression/issue/17454/destructure_string.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/17605.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/17766.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/17793.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/18028.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/18159/18159.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/18161.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/18242.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/18413-all-compressions.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/18413-deflate-semantics.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `regression/issue/18413-truncation.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `regression/issue/18413.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/18547.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/18595.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/18820.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/19107.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/19111.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/19219.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/19412.test.ts` |  | ✅2/0⊘2 | ✅2/0⊘2 | both-pass |  |
| `regression/issue/19652.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/19661.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/19758.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/19850/19850.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/19875.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/20053.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/20092.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/20100.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/20321.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/20546.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/20753.test.js` |  ⊘1+1 | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/20875.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/20965.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/20980.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/21137-minify-typeof-comma.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/21177.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/21257.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/21274.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/21654/21654.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/21677.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/21680.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/21792.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `regression/issue/21830.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/21907.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/22003.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/22157.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/22199.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/22243.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/22317.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/22353.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/22475.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/22481.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/22635/22635.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/22656.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/22712.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/22743.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/22929-module-extensions-asi.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/22978-createargv-double-free.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/23022-stack-trace-iterator.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/23077/23077.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/23133.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/23139.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/23183.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/23275.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/23287-array-comma-value.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/23292.test.ts` |  | ✅0/0⊘4 | ✅0/0⊘4 | both-pass |  |
| `regression/issue/23314/zstd-async-compress.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/23314/zstd-large-decompression.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/23314/zstd-large-input.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/23316-long-path-spawn-shell.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/23316-long-path-spawn.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/23382.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/23474.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/23489.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/23569.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/23621.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `regression/issue/23649.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/23723.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/23865.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/24007.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/24045.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/24129.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/24131.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/24147.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/24157.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/24191.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/24234.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/24314.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/24329.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/24338.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `regression/issue/24339.test.ts` |  | ✅0/0⊘2 | ✅0/0⊘2 | both-pass |  |
| `regression/issue/24374.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/24385.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `regression/issue/24387.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/24388.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/24399.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/24502/bun-pm-ls-all-invalid-package-id.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/24575.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/24593.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/246-child_process_object_assign_compatibility.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/24709.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/24806.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/24817.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/24924.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/25190.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/25231.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/25398.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/25432.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/25589-frame-size-connect.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/25589-frame-size-grpc.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/25589-write-end.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/25589.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `regression/issue/25609.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/25622.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/25628.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/25639.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/25648.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/25707.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/25716.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/25750.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `regression/issue/25785.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/25794.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/25831.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/25862.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/25869.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/26058.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/26088.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/26125.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/26142.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/26143.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/26284.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/26286.test.ts` |  ⊘2+2 | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/26298.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/26337.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/26338.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/26358.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/26360.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/26377.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/26387.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/26411.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/26460.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/26631.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `regression/issue/26632.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/26647.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/26669.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/26844.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/26851.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/26915.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/27014.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/27025.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/27049.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/27061.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/27099.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/27117.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/27358.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/27389.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/27428.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/27431.test.ts` |  | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `regression/issue/27445.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/27458.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/27465.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/27478.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/27526.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/27553.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/27575.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/27598.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/27849.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/27890.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/27974.test.ts` |  | ✅6/0⊘1 | ✅6/0⊘1 | both-pass |  |
| `regression/issue/28004.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/28014.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/28017.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/28024.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/28042.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/28083.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/28170.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/28193.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/28431.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/28522.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/28706.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/28756.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/28914.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/28948.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `regression/issue/28954.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/29072.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅1/0 | both-pass |  |
| `regression/issue/29073.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `regression/issue/29120.test.ts` |  ⊘1+1 | ✅0/0⊘2 | ✅0/0⊘2 | both-pass |  |
| `regression/issue/29169.test.ts` |  ⊘1+1 | ✅1/0⊘1 | ✅2/0 | both-pass |  |
| `regression/issue/29181.test.ts` |  ⊘1+1 | ✅1/0⊘1 | ✅2/0 | both-pass |  |
| `regression/issue/29225.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/29240.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/29242.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `regression/issue/29264.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/29267/29267.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/29268.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/29283.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/29298.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/29371.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/29519.test.ts` |  ⊘1+1 | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/29524.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `regression/issue/29585.test.ts` |  | ✅0/0⊘2 | ✅2/0 | both-pass |  |
| `regression/issue/29684.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `regression/issue/29780.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/29787.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/29925.test.ts` |  ⊘1+1 | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/2993.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `regression/issue/30205.test.ts` |  ⊘4+4 | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/30429.test.ts` |  | ✅0/0⊘5 | ✅0/0⊘5 | both-pass |  |
| `regression/issue/30493.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/30717.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/30887.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/30963.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/31002.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/31401.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/31503.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/31575.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/31611.test.ts` |  ⊘1+1 | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/31636.test.ts` |  | ✅0/0⊘2 | ✅0/0⊘2 | both-pass |  |
| `regression/issue/31652.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/3179.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/3192.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/32178.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/32489.test.ts` |  ⊘1+1 | ✅0/0⊘2 | ✅2/0 | both-pass |  |
| `regression/issue/32686.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `regression/issue/32728.test.ts` |  ⊘2+2 | ✅1/0⊘2 | ✅1/0⊘2 | both-pass |  |
| `regression/issue/32734.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/32793.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/33227.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/34415.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/34485.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/3613.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/36450.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/3657.test.ts` |  ⊘1+1 | ✅0/0⊘2 | ✅2/0 | both-pass |  |
| `regression/issue/36577.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/38087.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/440.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/5228.test.js` |  ⊘2+2 | ✅4/0 | ✅4/0 | both-pass |  |
| `regression/issue/5344.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/5738.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/5961.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/8254.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/atomics-waitasync-wtftimer-uaf.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/bundler-plugin-onresolve-entrypoint.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/circular-error-stack-edge-cases.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/circular-error-stack.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/comma-operator-this-binding.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/compile-outfile-subdirs.test.ts` |  | ✅0/0⊘8 | ✅0/0⊘8 | both-pass |  |
| `regression/issue/crypto-names.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/css-system-color-contexts.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/css-system-color-mix-crash.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/cyclic-imports-async-bundler.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/ENG-24434.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/fix-bindings-stack-trace.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/fuzzer-ENG-22942.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/hashbang-still-works.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/htmlrewriter-additional-bugs.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `regression/issue/invalid-escape-sequences.test.ts` |  | ✅37/0 | ✅37/0 | both-pass |  |
| `regression/issue/isArray-proxy-crash.test.ts` |  ⊘1+1 | ✅9/0 | ✅9/0 | both-pass |  |
| `regression/issue/issue-12276.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/issue-1825-jest-mock-functions.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/jsx-template-string-crash.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/malformed-integrity-base64.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/minify-new-array-with-if.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/napi-exception-pending-crash.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/patch-bounds-check.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/pe-codesigning-integrity.test.ts` |  | ✅0/0⊘6 | ✅0/0⊘6 | both-pass |  |
| `regression/issue/postgres-null-byte-injection.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/postgres-stringbuilder-assertion-aggressive.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/prepare-stack-trace-crash.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/require-extensions-override.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `regression/issue/s3-header-injection.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `regression/issue/s3-signature-order.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/s3-signature-performance.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/server-stop-with-pending-requests.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/stdin-pause-resume.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/test_env_loader_threading.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/test-21049.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `regression/issue/text-chunk-null-access.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `regression/issue/tty-readstream-ref-unref.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/tty-reopen-after-stdin-eof.test.ts` |  ⊘2+2 | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/tui-app-tty-pattern.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/update-interactive-formatting.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `regression/issue/utf16-encoding-crash.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue/yaml-parse-syntax-error.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |

## Bun API（509 文件 / 62 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `js/bun/binary/tls-segment-size.test.ts` | 🔧ohos ⊘2+2 | ✅0/0⊘2 | ❌0/1⊘1 | B-only-fail |  |
| `js/bun/console/console-iterator.test.ts` |  | ✅17/0 | ❌9/8 | B-only-fail |  |
| `js/bun/ffi/addr32.test.ts` | 🔧ohos ⊘1+1 | ✅0/0⊘1 | ❌0/1 | B-only-fail |  |
| `js/bun/http/serve-directory-routes.test.ts` | 🔧ohos ⊘3+3 | ✅28/0⊘3 | ❌4/26⊘1 | B-only-fail |  |
| `js/bun/http/serve-file-slice-read-error.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ❌0/1 | B-only-fail |  |
| `js/bun/io/bun-write.test.js` |  ⊘4+4 | ✅44/0⊘3 | ❌46/1⊘3 | B-only-fail |  |
| `js/bun/net/unix-socket-long-path.test.ts` | 🔧适配 ⊘1+1 | ✅0/0⊘4 | ❌0/4 | B-only-fail |  |
| `js/bun/shell/commands/ls.test.ts` | 🔧适配 | ✅22/0⊘7 | ❌27/2 | B-only-fail |  |
| `js/bun/shell/commands/mv.test.ts` | 🔧ohos ⊘7+8 | ✅6/0⊘7 | ❌6/7 | B-only-fail |  |
| `js/bun/shell/commands/which.test.ts` |  ⊘1+1 | ✅5/0 | ❌4/1 | B-only-fail |  |
| `js/bun/shell/env.positionals.test.ts` |  | ✅6/0 | ❌2/4 | B-only-fail |  |
| `js/bun/shell/exec.test.ts` |  | ✅19/0 | ❌6/13 | B-only-fail |  |
| `js/bun/shell/file-io.test.ts` |  | ✅26/0⊘1 | ❌26/1 | B-only-fail |  |
| `js/bun/shell/shell-cmdsub-crash.test.ts` |  ⊘1+1 | ✅1/0 | ⏰ | B-only-fail |  |
| `js/bun/shell/shell-seq-condexpr.test.ts` |  | ✅5/0 | ❌2/3 | B-only-fail |  |
| `js/bun/shell/yield.test.ts` |  | ✅1/0⊘3 | ❌3/1 | B-only-fail |  |
| `js/bun/spawn/spawn-pipe-read-error-leak.test.ts` | 🔧ohos ⊘1+1 | ✅1/0⊘1 | ❌1/1 | B-only-fail |  |
| `js/bun/spawn/spawn-signal.test.ts` |  | ✅12/0 | ❌11/1 | B-only-fail |  |
| `js/bun/spawn/spawn-stdin-readable-stream-integration.test.ts` |  | ✅5/0 | ❌4/1 | B-only-fail |  |
| `js/bun/symbols.test.ts` |  | ✅0/0 | ❌1/1 | B-only-fail |  |
| `js/bun/transpiler/transpiler-truncated-utf8.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ❌0/1 | B-only-fail |  |
| `js/bun/bun-object/write.spec.ts` |  | ❌20/3 | ❌20/3 | both-fail | env-baseline |
| `js/bun/dns/resolve-dns.test.ts` | 🔧ohos ⊘1+1 | ❌69/11⊘1 | ❌66/14⊘1 | both-fail | env-baseline |
| `js/bun/ffi/cc.test.ts` | 🔧ohos ⊘16+16 | ❌4/16⊘9 | ❌4/16⊘9 | both-fail | env-baseline |
| `js/bun/glob/scan.test.ts` | 🔧ohos ⊘5+6 | ❌193/1⊘1 | ❌193/1⊘1 | both-fail | env-baseline |
| `js/bun/http/bun-listen-connect-args.test.ts` | 🔧ohos | ❌0/5 | ❌0/5 | both-fail | env-baseline |
| `js/bun/http/bun-serve-args.test.ts` | 🔧ohos ⊘1+1 | ❌50/9 | ❌50/9 | both-fail | env-baseline |
| `js/bun/http/bun-serve-file.test.ts` |  ⊘3+3 | ❌103/2⊘1 | ❌103/2⊘1 | both-fail | env-baseline |
| `js/bun/http/serve-http3.test.ts` |  ⊘1+1 | ❌49/1⊘1 | ❌49/1⊘1 | both-fail | env-baseline |
| `js/bun/http/serve-listen.test.ts` |  ⊘1+1 | ❌24/0⊘1 | ❌25/0 | both-fail | env-baseline |
| `js/bun/http/serve.test.ts` | 🔧ohos ⊘1+1 | ❌292/2⊘3 | ❌293/4⊘1 | both-fail | env-baseline |
| `js/bun/http/server-url-invalid.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/bun/net/socket.test.ts` |  ⊘9+9 | ❌86/4⊘4 | ❌87/4⊘3 | both-fail | env-baseline |
| `js/bun/net/unix-socket-unlink.test.ts` |  ⊘2+2 | ❌1/7⊘1 | ❌2/7 | both-fail | env-baseline |
| `js/bun/patch/patch.test.ts` |  | ❌26/1 | ❌15/12 | both-fail | env-baseline |
| `js/bun/repl/repl.test.ts` |  ⊘1+1 | ⏰ | ❌157/12 | both-fail | env-baseline |
| `js/bun/resolve/resolve.test.ts` |  ⊘6+6 | ❌9/0⊘2 | ❌9/0⊘2 | both-fail | env-baseline |
| `js/bun/resolve/resolver-permission-denied-ancestor.test.ts` |  ⊘1+1 | ❌1/1 | ❌1/1 | both-fail | env-baseline |
| `js/bun/s3/s3-list-objects.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/bun/s3/s3.leak.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/bun/s3/s3.test.ts` |  ⊘5+5 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/bun/shell/bunshell-instance.test.ts` |  | ❌16/1 | ❌16/1 | both-fail | env-baseline |
| `js/bun/shell/bunshell.test.ts` |  ⊘1+1 | ❌421/1⊘2 | ⏰ | both-fail | env-baseline |
| `js/bun/shell/commands/rm.test.ts` | 🔧ohos ⊘3+3 | ❌7/2 | ❌8/1 | both-fail | env-baseline |
| `js/bun/shell/pipeline_stack.test.ts` | 🔧ohos | ❌61/2 | ❌61/2 | both-fail | env-baseline |
| `js/bun/shell/shell-hang.test.ts` |  | ❌0/6 | ❌0/6 | both-fail | env-baseline |
| `js/bun/shell/shell-load.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/bun/spawn/spawn-cgroup.test.ts` |  ⊘3+3 | ❌0/1⊘12 | ❌4/4⊘5 | both-fail | env-baseline |
| `js/bun/spawn/spawn-maxbuf.test.ts` |  ⊘1+1 | ❌12/4 | ❌12/4 | both-fail | env-baseline |
| `js/bun/spawn/spawn-pipe-leak.test.ts` | 🔧ohos | ❌0/3 | ❌0/3 | both-fail | env-baseline |
| `js/bun/spawn/spawn-stdin-readable-stream.test.ts` | 🔧ohos ⊘1+1 | ❌35/1 | ❌35/1 | both-fail | env-baseline |
| `js/bun/spawn/spawn-streaming-stdin.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/bun/spawn/spawn.test.ts` | 🔧ohos ⊘15+15 | ⏰ | ⏰ | both-fail | env-baseline |
| `js/bun/spawn/spawnSync.test.ts` |  ⊘5+5 | ❌3/2⊘13 | ❌13/2⊘3 | both-fail | env-baseline |
| `js/bun/terminal/terminal-platform-gaps.test.ts` |  | ❌16/3 | ⏰ | both-fail | env-baseline |
| `js/bun/terminal/terminal-spawn.test.ts` |  ⊘5+5 | ❌12/4⊘1 | ❌12/4⊘1 | both-fail | env-baseline |
| `js/bun/terminal/terminal.test.ts` |  ⊘6+6 | ❌89/7⊘2 | ⏰ | both-fail | env-baseline |
| `js/bun/util/filesink.test.ts` | 🔧ohos ⊘11+11 | ❌34/18⊘10 | ❌43/19 | both-fail | env-baseline |
| `js/bun/util/sleep.test.ts` |  | ❌1/1 | ❌1/1 | both-fail | env-baseline |
| `js/bun/websocket/websocket-server.test.ts` |  | ❌86/31 | ❌85/32 | both-fail | env-baseline |
| `js/bun/glob/path-length.test.ts` |  ⊘2+2 | ❌3/2⊘1 | ✅6/0 | A-only-fail |  |
| `js/bun/util/mmap.test.js` | 🔧ohos ⊘1+1 | ❌20/1 | ✅21/0 | A-only-fail |  |
| `js/bun/archive.test.ts` |  ⊘3+3 | ✅106/0⊘1 | ✅106/0⊘1 | both-pass |  |
| `js/bun/bun-object/deep-equals-temporal.test.ts` |  | ✅77/0 | ✅77/0 | both-pass |  |
| `js/bun/bun-object/deep-equals.test.ts` |  ⊘2+2 | ✅44/0⊘3 | ✅44/0⊘3 | both-pass |  |
| `js/bun/bun-object/deep-match.spec.ts` |  ⊘1+1 | ✅47/0⊘1 | ✅47/0⊘1 | both-pass |  |
| `js/bun/bundler/yaml-bundler.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/compile/standalone-madvise-tla.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/bun/console/bun-inspect-table.test.ts` |  | ✅35/0 | ✅35/0 | both-pass |  |
| `js/bun/console/console-table.test.ts` |  ⊘1+1 | ✅32/0⊘1 | ✅32/0⊘1 | both-pass |  |
| `js/bun/console/console-write.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/cookie/cookie-exotic-inputs.test.ts` |  | ✅24/0 | ✅24/0 | both-pass |  |
| `js/bun/cookie/cookie-expires-validation.test.ts` |  | ✅22/0 | ✅22/0 | both-pass |  |
| `js/bun/cookie/cookie-map.test.ts` |  | ✅33/0 | ✅33/0 | both-pass |  |
| `js/bun/cookie/cookie-security-fuzz.test.ts` |  | ✅47/0 | ✅47/0 | both-pass |  |
| `js/bun/cookie/cookie.test.ts` |  | ✅35/0 | ✅35/0 | both-pass |  |
| `js/bun/cron/cron-local-time.test.ts` |  | ✅30/0 | ✅30/0 | both-pass |  |
| `js/bun/cron/cron-parse.test.ts` |  | ✅23/0 | ✅23/0 | both-pass |  |
| `js/bun/cron/cron.test.ts` |  ⊘11+11 | ✅54/0⊘63 | ✅54/0⊘63 | both-pass |  |
| `js/bun/cron/in-process-cron.test.ts` |  | ✅27/0 | ✅27/0 | both-pass |  |
| `js/bun/crypto/cipheriv-decipheriv.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/bun/crypto/wpt-webcrypto.generateKey.test.ts` |  | ✅10226/0 | ✅10226/0 | both-pass |  |
| `js/bun/crypto/x25519-derive-bits.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/bun/css/angle-serialization-hang.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/css/atan2-backtracking-hang.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/css/attr-selector-namespace-star.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/css/color.test.ts` |  ⊘1+1 | ✅1023/0 | ✅1023/0 | both-pass |  |
| `js/bun/css/css-fuzz.test.ts` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/bun/css/css-loader.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/css/css.test.ts` |  ⊘1+1 | ✅1181/0⊘67 | ✅1181/0⊘67 | both-pass |  |
| `js/bun/css/custom-pseudo-ident-escape.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/bun/css/doesnt_crash.test.ts` |  | ✅61/0 | ✅61/0 | both-pass |  |
| `js/bun/css/duplicate-declaration-merge-hang.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/css/invalid-utf8-column.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/css/nested-function-backtracking.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/css/nested-selector-expansion.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/css/nested-selector-list-expansion.test.ts` |  | ✅24/0 | ✅24/0 | both-pass |  |
| `js/bun/css/nested-vendor-prefix-duplication.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/bun/css/nth-anplusb-ident.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/css/selector-list-error-recovery.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/bun/css/small-list-grow.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/css/supports-condition-newline.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/css/token-list-backtracking.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/dns/dns-interleave.test.ts` |  ⊘1+1 | ✅3/0⊘1 | ✅3/0⊘1 | both-pass |  |
| `js/bun/dns/dns-prefetch.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/empty-file.test.ts` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/bun/fetch/node-use-system-ca.test.ts` |  | ✅1/0⊘2 | ✅1/0⊘2 | both-pass |  |
| `js/bun/ffi/ffi-error-messages.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/ffi/ffi-viewSource-non-object.test.ts` |  | ✅28/0 | ✅28/0 | both-pass |  |
| `js/bun/ffi/ffi.test.js` |  ⊘6+6 | ✅147/0⊘5 | ✅147/0⊘5 | both-pass |  |
| `js/bun/ffi/mh-execute-header.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/bun/gc/gc-controller-cadence.test.ts` |  ⊘1+1 | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/glob/leak.test.ts` | 🔧ohos | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/glob/match.test.ts` |  | ✅29/0 | ✅29/0 | both-pass |  |
| `js/bun/glob/proto.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/glob/stress.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/globals.test.js` |  | ✅20/0 | ✅20/0 | both-pass |  |
| `js/bun/http/async-iterator-stream.test.ts` |  | ✅91/0 | ✅91/0 | both-pass |  |
| `js/bun/http/bun-connect-x509.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/http/bun-serve-body-json-async.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/bun-serve-cookies.test.ts` |  | ✅25/0 | ✅25/0 | both-pass |  |
| `js/bun/http/bun-serve-date.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/bun-serve-fetch-invalid-args.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/bun-serve-headers.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/http/bun-serve-html-405.test.ts` |  ⊘2+2 | ✅1/0⊘2 | ✅1/0⊘2 | both-pass |  |
| `js/bun/http/bun-serve-html-build-holds-server.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/http/bun-serve-html-entry.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/bun/http/bun-serve-html-hot-reload-drop.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/bun-serve-html-manifest.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/http/bun-serve-html.test.ts` |  | ✅21/0 | ✅21/0 | both-pass |  |
| `js/bun/http/bun-serve-propagate-errors.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/bun-serve-routes.test.ts` |  | ✅61/0 | ✅61/0 | both-pass |  |
| `js/bun/http/bun-serve-ssl.test.ts` |  | ✅18/0 | ✅18/0 | both-pass |  |
| `js/bun/http/bun-serve-static-stress-access-body.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/bun/http/bun-serve-static-stress-no-body.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/bun/http/bun-serve-static.test.ts` |  | ✅46/0 | ✅46/0 | both-pass |  |
| `js/bun/http/bun-server.test.ts` |  ⊘1+1 | ✅78/0⊘1 | ✅78/0⊘1 | both-pass |  |
| `js/bun/http/decodeURIComponentSIMD.test.ts` |  | ✅229/0 | ✅229/0 | both-pass |  |
| `js/bun/http/fetch-abort-ssl-context-eviction.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/fetch-file-upload.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/bun/http/fetch-header-count-limit.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/http/form-data-set-append.test.js` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/http/getIfPropertyExists.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/http/hspec.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/http-server-chunking.test.ts` |  | ✅0/0⊘13 | ✅13/0 | both-pass |  |
| `js/bun/http/leaks-test.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/http/listener-getsockname.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/http/node-http-halfclose-midupload.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/http/node-http2-ping-flood-staged.test.ts` |  ⊘1+1 | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/http/proxy-stress-adversarial.test.ts` |  | ✅151/0 | ✅151/0 | both-pass |  |
| `js/bun/http/proxy-stress-concurrent.test.ts` |  | ✅43/0 | ✅43/0 | both-pass |  |
| `js/bun/http/proxy-stress-errors.test.ts` |  | ✅53/0 | ✅53/0 | both-pass |  |
| `js/bun/http/proxy-stress-headers.test.ts` |  | ✅76/0 | ✅76/0 | both-pass |  |
| `js/bun/http/proxy-stress-lifecycle.test.ts` |  ⊘1+1 | ✅92/0⊘1 | ✅92/0⊘1 | both-pass |  |
| `js/bun/http/proxy-stress-matrix.test.ts` |  | ✅335/0 | ✅335/0 | both-pass |  |
| `js/bun/http/proxy-stress-protocol.test.ts` |  ⊘1+1 | ✅102/0 | ✅102/0 | both-pass |  |
| `js/bun/http/proxy.test.js` |  | ✅16/0⊘8 | ✅16/0⊘8 | both-pass |  |
| `js/bun/http/proxy.test.ts` |  ⊘1+1 | ✅67/0⊘1 | ✅67/0⊘1 | both-pass |  |
| `js/bun/http/req-url-leak.test.ts` | 🔧ohos | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/request-smuggling.test.ts` |  | ✅87/0 | ✅87/0 | both-pass |  |
| `js/bun/http/serve-async-stream-client-abort.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/http/serve-body-leak.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/bun/http/serve-close-delimited-framing.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/http/serve-direct-readable-stream.test.ts` |  ⊘4+4 | ✅20/0⊘4 | ✅20/0⊘4 | both-pass |  |
| `js/bun/http/serve-epoll-add-fail.test.ts` |  | ✅0/0⊘6 | ✅6/0 | both-pass |  |
| `js/bun/http/serve-error-handler-stream.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/bun/http/serve-if-none-match.test.ts` |  | ✅28/0 | ✅28/0 | both-pass |  |
| `js/bun/http/serve-pending-promise-abort-leak.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/http/serve-protocols.test.ts` |  | ✅20/0 | ✅20/0 | both-pass |  |
| `js/bun/http/serve-request-extra-memory.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/serve-response-gc-backpressure-abort.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/bun/http/serve-response-stream-sink-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/serve-reused-response.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/bun/http/serve-stream-body-error.test.ts` |  ⊘1+1 | ✅14/0⊘1 | ✅14/0⊘1 | both-pass |  |
| `js/bun/http/serve-stream-reject-flush-leak.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/serve-syscall-fault.test.ts` |  ⊘1+1 | ✅0/0⊘5 | ✅0/0⊘5 | both-pass |  |
| `js/bun/http/tls-bunfile-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/http/tls-keepalive.test.ts` |  ⊘1+1 | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/image/image-adversarial.test.ts` |  | ✅61/0 | ✅61/0 | both-pass |  |
| `js/bun/image/image-kernels.test.ts` |  | ✅37/0 | ✅37/0 | both-pass |  |
| `js/bun/image/image-vs-sharp.test.ts` |  | ✅29/0 | ✅29/0 | both-pass |  |
| `js/bun/image/image.test.ts` |  ⊘2+2 | ✅95/0⊘2 | ✅95/0⊘2 | both-pass |  |
| `js/bun/import-attributes/import-attributes.test.ts` | ⏱超时预算 | ✅12/0 | ✅12/0 | both-pass |  |
| `js/bun/ini/ini.test.ts` |  | ✅62/0 | ✅62/0 | both-pass |  |
| `js/bun/io/bun-write-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/io/fetch/fetch-abort-slow-connect.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/jsc-stress/jsc-stress.test.ts` |  ⊘1+1 | ✅83/0⊘32 | ✅83/0⊘32 | both-pass |  |
| `js/bun/jsc-stress/testFFI.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/bun/jsc/bun-jsc.test.ts` |  | ✅38/0 | ✅38/0 | both-pass |  |
| `js/bun/jsc/domjit.test.ts` |  | ✅50/0 | ✅50/0 | both-pass |  |
| `js/bun/jsc/heapStats-mimalloc.test.ts` |  ⊘1+1 | ✅4/0⊘1 | ✅4/0⊘1 | both-pass |  |
| `js/bun/jsc/native-constructor-identity.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/jsc/shadow.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/jsc/string-noAtomize.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/jsc/temporal-global.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/jsc/webkit-upgrade-3722912f.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/json5/json5-test-suite.test.ts` |  | ✅113/0 | ✅113/0 | both-pass |  |
| `js/bun/json5/json5.test.ts` |  | ✅321/0 | ✅321/0 | both-pass |  |
| `js/bun/jsonc/json-differential-fuzz.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/jsonc/json-test-suite.test.ts` |  | ✅319/0 | ✅319/0 | both-pass |  |
| `js/bun/jsonc/jsonc.test.ts` |  | ✅48/0 | ✅48/0 | both-pass |  |
| `js/bun/jsonl/jsonl-parse.test.ts` |  | ✅269/0 | ✅269/0 | both-pass |  |
| `js/bun/md/gfm-compat.test.ts` |  | ✅62/0 | ✅62/0 | both-pass |  |
| `js/bun/md/md-edge-cases.test.ts` |  | ✅84/0 | ✅84/0 | both-pass |  |
| `js/bun/md/md-heading-ids.test.ts` |  | ✅17/0 | ✅17/0 | both-pass |  |
| `js/bun/md/md-react.test.ts` |  | ✅73/0 | ✅73/0 | both-pass |  |
| `js/bun/md/md-render-callback.test.ts` |  | ✅40/0 | ✅40/0 | both-pass |  |
| `js/bun/md/md-spec.test.ts` |  | ✅792/0 | ✅792/0 | both-pass |  |
| `js/bun/memfd-disabled.test.ts` |  ⊘2+2 | ✅0/0⊘2 | ✅2/0 | both-pass |  |
| `js/bun/namespace-prototype-pollution.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/net/localhost-loopback-contract.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/net/named-pipe-listen-error.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/bun/net/socket-dns-error.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/net/socket-retention.test.ts` |  ⊘1+1 | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/net/socket-syscall-fault.test.ts` |  ⊘4+4 | ✅1/0⊘8 | ✅1/0⊘8 | both-pass |  |
| `js/bun/net/tcp-server.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/bun/perf_hooks/histogram.test.ts` |  | ✅38/0 | ✅38/0 | both-pass |  |
| `js/bun/perf/linker-order.test.ts` |  ⊘6+6 | ✅23/0⊘7 | ✅24/0⊘6 | both-pass |  |
| `js/bun/perf/static-initializers.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/bun/plugin/plugin-namespace-drive-letter.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/plugin/plugins.test.ts` |  | ✅42/0 | ✅42/0 | both-pass |  |
| `js/bun/resolve/build-error.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/resolve/builtin-esm-lazy-exports.test.ts` |  | ✅15/0 | ✅15/0 | both-pass |  |
| `js/bun/resolve/bun-lock.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/resolve/bun-main-entry-point.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/resolve/concurrent-dynamic-import.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/resolve/dynamic-import-tla-cycle.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/resolve/esModule-annotation.test.js` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/bun/resolve/esModule.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/resolve/import-custom-condition.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/bun/resolve/import-defer.test.ts` |  | ✅20/0 | ✅20/0 | both-pass |  |
| `js/bun/resolve/import-empty.test.js` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/bun/resolve/import-meta-resolve.test.mjs` |  | ✅15/0 | ✅15/0 | both-pass |  |
| `js/bun/resolve/import-meta.test.js` |  | ✅32/0 | ✅32/0 | both-pass |  |
| `js/bun/resolve/import-query.test.ts` |  | ✅15/0 | ✅15/0 | both-pass |  |
| `js/bun/resolve/json5/json5.test.js` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/resolve/jsonc.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/resolve/load-file-loader-a-lot.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/bun/resolve/load-same-js-file-a-lot.test.ts` | 🔧ohos | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/resolve/lower-using-bun-target.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/bun/resolve/non-english-import.test.js` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/resolve/png/test-png-import.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/resolve/require-esm-gc-roots.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/resolve/require-esm-microtask-order.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/resolve/require-esm-transitive-tla.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/resolve/require.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/bun/resolve/resolve-autoinstall-invalid-name.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/resolve/resolve-autoinstall-log-dangling.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/resolve/resolve-bad-parent.test.mjs` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/resolve/resolve-error.test.ts` |  | ✅22/0 | ✅22/0 | both-pass |  |
| `js/bun/resolve/resolve-ts.test.ts` |  | ✅27/0 | ✅27/0 | both-pass |  |
| `js/bun/resolve/star-export-namespace.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/resolve/toml/crash/toml-crash.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/resolve/toml/toml-parse.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/bun/resolve/toml/toml.test.js` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/bun/resolve/tsconfig-extends-leak.test.ts` |  ⊘1+1 | ✅1/0⊘1 | ✅1/0⊘1 | both-pass |  |
| `js/bun/resolve/xml/xml.test.js` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/bun/resolve/yaml/yaml.test.js` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/runtime-error.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/s3/s3-argument-validation.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `js/bun/s3/s3-connection-close.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/bun/s3/s3-fd-validation.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/s3/s3-insecure.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/s3/s3-list-checksum-algorithm.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/s3/s3-list-encode-overflow.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/bun/s3/s3-numeric-options-coerce.test.ts` |  | ✅17/0 | ✅17/0 | both-pass |  |
| `js/bun/s3/s3-queueSize-validation.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/s3/s3-requester-pays.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/bun/s3/s3-storage-class.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/bun/s3/s3-stream-cancel-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/s3/s3-stream-error-gc.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/s3/s3-write-to-file-sync-close.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/secrets-error-codes.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/secrets.test.ts` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/bun/shell/assignments-in-pipeline.test.ts` |  | ✅38/0 | ✅38/0 | both-pass |  |
| `js/bun/shell/brace.test.ts` |  | ✅43/0 | ✅43/0 | both-pass |  |
| `js/bun/shell/bunshell-default.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/shell/bunshell-file.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/shell/commands/basename.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/bun/shell/commands/cp.test.ts` |  | ✅0/0⊘30 | ✅0/0⊘30 | both-pass |  |
| `js/bun/shell/commands/dirname.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/bun/shell/commands/echo.test.ts` |  | ✅22/0 | ✅22/0 | both-pass |  |
| `js/bun/shell/commands/exit.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/bun/shell/commands/false.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/shell/commands/mkdir.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/shell/commands/seq.test.ts` |  ⊘1+1 | ✅31/0⊘1 | ✅31/0⊘1 | both-pass |  |
| `js/bun/shell/commands/touch.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/shell/commands/true.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/shell/commands/yes.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/shell/epipe.test.ts` |  | ✅0/0⊘2 | ✅2/0 | both-pass |  |
| `js/bun/shell/lazy.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/shell/leak.test.ts` | 🔧ohos | ✅35/0⊘7 | ✅42/0 | both-pass |  |
| `js/bun/shell/lex.test.ts` |  | ✅43/0 | ✅43/0 | both-pass |  |
| `js/bun/shell/parse.test.ts` |  | ✅18/0 | ✅18/0 | both-pass |  |
| `js/bun/shell/shell-blocking-pipe.test.ts` |  ⊘2+2 | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/shell/shell-leak-args.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/shell/shell-pipe-read-fault.test.ts` |  | ✅0/0⊘8 | ✅5/0⊘3 | both-pass |  |
| `js/bun/shell/shell-sentinel-hardening.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/shell/shell-worker-terminate-leak.test.ts` |  ⊘7+7 | ✅0/0⊘7 | ✅1/0⊘6 | both-pass |  |
| `js/bun/shell/shell-write-fault.test.ts` |  | ✅0/0⊘1 | ✅1/0 | both-pass |  |
| `js/bun/shell/shelloutput.test.ts` |  ⊘1+1 | ✅2/0⊘1 | ✅3/0 | both-pass |  |
| `js/bun/shell/throw.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/sourcemap/internal-sourcemap-roundtrip.test.ts` |  | ✅22/0 | ✅22/0 | both-pass |  |
| `js/bun/sourcemap/internal-sourcemap.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/sourcemap/negative-vlq-mapping.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/bun/spawn/bun-ipc-inherit.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/exit-code.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/spawn/job-object-bug.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/null-byte-injection.test.ts` |  | ✅20/0 | ✅20/0 | both-pass |  |
| `js/bun/spawn/pidfd-exit-nested-tick.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅1/0 | both-pass |  |
| `js/bun/spawn/readablestream-helpers.test.ts` |  | ✅30/0 | ✅30/0 | both-pass |  |
| `js/bun/spawn/spawn_waiter_thread.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn-empty-arrayBufferOrBlob.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/spawn/spawn-env.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn-ipc-gc.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn-kill-signal.test.ts` |  | ✅16/0 | ✅16/0 | both-pass |  |
| `js/bun/spawn/spawn-large-array-length.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/spawn/spawn-many-teardown.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn-noread-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn-path.test.ts` |  ⊘2+2 | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/spawn/spawn-pipe-stale-fd-unregister.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn-pipe-start-error.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/bun/spawn/spawn-renamed-cwd.test.ts` |  ⊘2+2 | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/spawn/spawn-socketpair-shutdown.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/spawn/spawn-stdin-destroy.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn-stdin-pipe-fd-leak.test.ts` |  ⊘3+3 | ✅1/0⊘3 | ✅3/0⊘1 | both-pass |  |
| `js/bun/spawn/spawn-stdin-readable-stream-edge-cases.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/bun/spawn/spawn-stdin-readable-stream-sync.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn-stdout-filereader-gc-uaf.test.ts` |  ⊘3+3 | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/spawn/spawn-stdout-iterate-leak.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/bun/spawn/spawn-stream-serve.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn-streaming-stdout.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn-stress.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn-unread-stdout-gc.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn.ipc.bun-node.test.ts` |  ⊘2+2 | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/spawn/spawn.ipc.node-bun.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/spawn/spawn.ipc.test.ts` |  ⊘2+2 | ✅15/0 | ✅15/0 | both-pass |  |
| `js/bun/spawn/spawnsync-isolated-event-loop.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/spawn/spawnsync-no-microtask-drain.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/sqlite/column-types.test.js` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/bun/sqlite/sql-timezone.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/sqlite/sqlite.test.js` |  ⊘1+1 | ✅122/0 | ✅122/0 | both-pass |  |
| `js/bun/stream/direct-readable-stream.test.tsx` |  ⊘3+3 | ✅269/0⊘268 | ✅269/0⊘268 | both-pass |  |
| `js/bun/sys/error-name-from-libuv.test.ts` |  ⊘2+2 | ✅1/0⊘1 | ✅1/0⊘1 | both-pass |  |
| `js/bun/sys/fstat-windows-crt-fd-leak.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/bun/test/bun_test.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/bun/test/bun-test.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/test/ci-restrictions.test.ts` |  ⊘1+1 | ✅12/0 | ✅12/0 | both-pass |  |
| `js/bun/test/concurrent_immediate.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/test/concurrent.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/test/describe.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `js/bun/test/done-async.test.ts` |  | ✅0/7 | ✅0/7 | both-pass |  |
| `js/bun/test/dots.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/test/expect-assertions.test.ts` |  | ✅0/5 | ✅0/5 | both-pass |  |
| `js/bun/test/expect-extend-asymmetric-match-throw.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/expect-extend-preload.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/expect-extend.test.js` |  | ✅28/0 | ✅28/0 | both-pass |  |
| `js/bun/test/expect-failure-message-angle-brackets.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/test/expect-formdata-tojson-crash.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/expect-label.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/test/expect-stack-overflow-crash.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/expect-symbol-toPrimitive-crash.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/expect-toHaveReturnedWith.test.js` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `js/bun/test/expect-type-doctest.test.ts` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/bun/test/expect-type-global.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/expect-type.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/expect-unreaachable.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/expect.test.js` |  | ✅415/0 | ✅415/0 | both-pass |  |
| `js/bun/test/expect/huge-failure-message.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/expect/toHaveReturnedWith.test.ts` |  | ✅42/0 | ✅42/0 | both-pass |  |
| `js/bun/test/failure-skip.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/bun/test/fake-timers/fake-timers.test.ts` |  | ✅47/0 | ✅47/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/fake-timers.test.ts` |  ⊘38+38 | ✅0/0 | ✅0/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-1852.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-187.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-207.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-2086.test.ts` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-2449.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-276.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-315.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-347.test.ts` |  ⊘1+1 | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-368.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-437.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-504.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-516.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-59.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-67.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/test/fake-timers/sinonjs/issue-73.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/jest-each-gc-root.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/jest-each.test.ts` |  | ✅25/0 | ✅25/0 | both-pass |  |
| `js/bun/test/jest-extended.test.js` |  | ✅58/0 | ✅58/0 | both-pass |  |
| `js/bun/test/jest-hooks.test.ts` |  | ✅17/0 | ✅17/0 | both-pass |  |
| `js/bun/test/mock-disposable.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/test/mock-fn.test.js` |  | ✅83/0 | ✅83/0 | both-pass |  |
| `js/bun/test/mock/6874/A.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/mock/6874/B.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/mock/6879/6879.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/test/mock/mock-module-non-string.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/test/mock/mock-module-resolve-log.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/mock/mock-module.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/bun/test/nested-describes.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/test/only-failures.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/test/only-inside-only.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/preload-test.test.js` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/bun/test/pretty-format-overflow.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/printing/diffexample.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/test/snapshot-tests/bun-snapshots.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/test/snapshot-tests/existing-snapshots.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/snapshot-tests/new-snapshot.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/spyMatchers.test.ts` |  | ✅150/0 | ✅150/0 | both-pass |  |
| `js/bun/test/stack.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/test/test-auto-import-jest-globals.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/test/test-error-code-done-callback.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/test-failing.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/bun/test/test-on-test-finished.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/bun/test/test-only.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/test-retry-repeats-basic.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/test/test-test.test.ts` |  ⊘11+11 | ✅24/0⊘16 | ✅24/0⊘16 | both-pass |  |
| `js/bun/test/test-timers.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/bun/toml/toml-test-suite.test.ts` |  | ✅708/0 | ✅708/0 | both-pass |  |
| `js/bun/toml/toml.test.ts` |  | ✅99/0 | ✅99/0 | both-pass |  |
| `js/bun/transpiler/parse-error-column.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/bun/transpiler/repl-transform.test.ts` |  | ✅36/0 | ✅36/0 | both-pass |  |
| `js/bun/transpiler/source-too-large.test.ts` |  ⊘1+1 | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/transpiler/transpiler-comma-chain-oom.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/transpiler/transpiler-error-gc-uaf.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/transpiler/transpiler-radix-bigint.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/transpiler/transpiler-tsconfig-uaf.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/transpiler/transpiler-unsupported-loader.test.ts` |  | ✅33/0 | ✅33/0 | both-pass |  |
| `js/bun/transpiler/transpiler-utf16-loader.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/typescript/type-export.test.ts` |  | ✅70/0⊘18 | ✅70/0⊘18 | both-pass |  |
| `js/bun/udp/dgram.test.ts` |  ⊘11+11 | ✅61/0 | ✅61/0 | both-pass |  |
| `js/bun/udp/udp_socket_recv_flags.test.ts` |  ⊘1+1 | ✅1/0⊘1 | ✅2/0 | both-pass |  |
| `js/bun/udp/udp_socket.test.ts` | 🔧ohos | ✅207/0 | ✅207/0 | both-pass |  |
| `js/bun/util/arraybuffersink.test.ts` |  ⊘1+1 | ✅13/0⊘1 | ✅13/0⊘1 | both-pass |  |
| `js/bun/util/base64-url-safe-encode.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/util/bun-cryptohasher.test.ts` |  | ✅403/0 | ✅403/0 | both-pass |  |
| `js/bun/util/bun-file-exists.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/util/bun-file-fd-read.test.ts` |  ⊘1+1 | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/util/bun-file-read.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/util/bun-file-windows.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/util/bun-file.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/util/bun-isMainThread.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/util/bun-main.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/util/bun-stdin-slice.test.ts` |  ⊘2+2 | ✅9/0 | ✅9/0 | both-pass |  |
| `js/bun/util/BunObject.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/util/bunstring-tothreadsafe.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/util/concat.test.js` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/util/cookie.test.js` |  ⊘3+3 | ✅101/0⊘18 | ✅101/0⊘18 | both-pass |  |
| `js/bun/util/csrf.test.ts` |  | ✅25/0 | ✅25/0 | both-pass |  |
| `js/bun/util/error-code-mirror.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/util/error-gc-test.test.js` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/util/error-name-preservation.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/util/escapeHTML.test.js` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/bun/util/escapeRegExp.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/util/exotic-global-mutable-prototype.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/util/file-type.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/util/filesystem_router.test.ts` |  ⊘2+2 | ✅33/0 | ✅33/0 | both-pass |  |
| `js/bun/util/fileUrl.test.js` |  | ✅20/0 | ✅20/0 | both-pass |  |
| `js/bun/util/fuzzilli-reprl.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/util/hash.test.js` |  | ✅20/0 | ✅20/0 | both-pass |  |
| `js/bun/util/heap-snapshot.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/bun/util/highlighter.test.ts` |  | ✅16/0 | ✅16/0 | both-pass |  |
| `js/bun/util/highway-strings.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/bun/util/index-of-line.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/util/inspect-error-leak.test.js` | 🔧ohos | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/util/inspect-error.test.js` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/bun/util/inspect.test.js` |  ⊘1+1 | ✅78/0⊘1 | ✅78/0⊘1 | both-pass |  |
| `js/bun/util/open-in-editor-gc.test.ts` |  ⊘3+3 | ✅0/0⊘3 | ✅3/0 | both-pass |  |
| `js/bun/util/password.test.ts` |  ⊘3+3 | ✅84/0 | ✅84/0 | both-pass |  |
| `js/bun/util/pathToFileURL-invalid.test.ts` |  ⊘1+1 | ✅1/0⊘1 | ✅1/0⊘1 | both-pass |  |
| `js/bun/util/peek.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/util/randomUUIDv5.test.ts` |  | ✅40/0 | ✅40/0 | both-pass |  |
| `js/bun/util/randomUUIDv7.test.ts` |  | ✅20/0 | ✅20/0 | both-pass |  |
| `js/bun/util/readablestreamtoarraybuffer.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/util/reportError.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/util/sleepSync.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/util/sliceAnsi-fuzz.test.ts` |  | ✅48/0 | ✅48/0 | both-pass |  |
| `js/bun/util/sliceAnsi.test.ts` |  | ✅166/0 | ✅166/0 | both-pass |  |
| `js/bun/util/socket-fault-injection.test.ts` |  ⊘3+3 | ✅2/0⊘16 | ✅2/0⊘16 | both-pass |  |
| `js/bun/util/stringWidth.test.ts` |  | ✅173/0 | ✅173/0 | both-pass |  |
| `js/bun/util/stripANSI.test.ts` |  | ✅296/0 | ✅296/0 | both-pass |  |
| `js/bun/util/text-loader.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/bun/util/toUTF16Alloc.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/util/unsafe.test.js` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/bun/util/v8-heap-snapshot.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/bun/util/which.test.ts` |  ⊘1+1 | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/util/wrapAnsi.npm.test.ts` |  | ✅23/0 | ✅23/0 | both-pass |  |
| `js/bun/util/wrapAnsi.test.ts` |  | ✅248/0 | ✅248/0 | both-pass |  |
| `js/bun/util/zstd.test.ts` |  ⊘1+1 | ✅88/0⊘4 | ✅88/0⊘4 | both-pass |  |
| `js/bun/wasm/wasi.test.js` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/websocket/websocket-server-backpressure-buffer.test.ts` |  ⊘1+1 | ✅2/0 | ✅2/0 | both-pass |  |
| `js/bun/websocket/websocket-server-reload-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/websocket/websocket-server-rsv-frames.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/bun/websocket/websocket-server-stop-retained-ws.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/websocket/websocket-server-unmasked-frames.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/websocket/websocket-server-upgrade-reentrant.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/bun/websocket/websocket-upgrade-signal-gc.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/bun/webview/webview-chrome-disconnect.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/bun/webview/webview-chrome-pipe.test.ts` |  | ✅7/0⊘2 | ✅7/0⊘2 | both-pass |  |
| `js/bun/webview/webview-chrome-ws.test.ts` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/bun/webview/webview-chrome.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/bun/webview/webview.test.ts` |  | ✅2/0⊘57 | ✅2/0⊘57 | both-pass |  |
| `js/bun/windows/appcontainer.test.ts` |  ⊘2+2 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/bun/xml/xml-test-suite.test.ts` |  | ✅1995/0 | ✅1995/0 | both-pass |  |
| `js/bun/xml/xml.test.ts` |  | ✅58/0 | ✅58/0 | both-pass |  |
| `js/bun/yaml/yaml-block-scalar-matrix.test.ts` |  | ✅1084/0 | ✅1084/0 | both-pass |  |
| `js/bun/yaml/yaml-test-suite.test.ts` |  | ✅402/0 | ✅402/0 | both-pass |  |
| `js/bun/yaml/yaml.test.ts` |  | ✅643/0 | ✅643/0 | both-pass |  |

## Node 兼容（314 文件 / 26 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `js/node/dns/node-dns.test.js` |  ⊘3+3 | ✅164/0⊘1 | ❌164/1 | B-only-fail |  |
| `js/node/fs/fs-birthtime-linux.test.ts` | 🔧ohos ⊘1+1 | ✅0/0⊘5 | ❌1/4 | B-only-fail |  |
| `js/node/fs/fs-oom.test.ts` |  ⊘2+2 | ✅2/0⊘2 | ❌9/4⊘2 | B-only-fail |  |
| `js/node/process/stdin/process-stdin-stale-hup.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ❌0/1 | B-only-fail |  |
| `js/node/child_process/child_process.test.ts` | 🔧ohos ⊘11+11 | ❌56/3⊘9 | ❌61/3⊘4 | both-fail | env-baseline |
| `js/node/child_process/child-process-rlimit-nofile.test.ts` | 🔧ohos | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/node/cluster.test.ts` |  ⊘10+10 | ❌25/6⊘1 | ❌26/6 | both-fail | env-baseline |
| `js/node/fs/cp.test.ts` |  ⊘8+8 | ❌41/4⊘7 | ❌42/5⊘5 | both-fail | env-baseline |
| `js/node/fs/fs-mkdir.test.ts` |  ⊘2+2 | ❌20/1⊘3 | ❌20/1⊘3 | both-fail | env-baseline |
| `js/node/fs/fs.test.ts` | 🔧ohos ⊘20+26 | ❌493/11⊘16 | ❌499/16⊘7 | both-fail | env-baseline |
| `js/node/http/node-http-connect.test.ts` |  ⊘2+2 | ❌7/0⊘1 | ❌7/0 | both-fail | env-baseline |
| `js/node/http/node-http.test.ts` | 🔧ohos ⊘1+2 | ❌143/2⊘1 | ❌143/2⊘1 | both-fail | env-baseline |
| `js/node/module/node-module-module.test.js` |  ⊘5+5 | ❌35/6⊘1 | ❌35/6⊘1 | both-fail | env-baseline |
| `js/node/module/sourcemap-simd.test.ts` |  | ❌23/1 | ❌0/24 | both-fail | env-baseline |
| `js/node/net/handle-leak.test.ts` |  | ⏰ | ⏰ | both-fail | env-baseline |
| `js/node/net/node-net-allowHalfOpen.test.js` |  ⊘1+1 | ❌2/1 | ❌2/1 | both-fail | env-baseline |
| `js/node/net/node-net-server.test.ts` |  | ❌19/3 | ❌19/3 | both-fail | env-baseline |
| `js/node/net/node-net.test.ts` |  ⊘8+8 | ❌69/7⊘7 | ❌69/7⊘7 | both-fail | env-baseline |
| `js/node/net/server.spec.ts` | 🔧ohos ⊘4+6 | ❌36/2⊘3 | ❌36/2⊘3 | both-fail | env-baseline |
| `js/node/process/dlopen-duplicate-load.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/node/process/process-stdin.test.ts` | 🔧ohos ⊘1+1 | ❌17/1 | ❌17/1 | both-fail | env-baseline |
| `js/node/process/process.test.js` | 🔧ohos ⊘10+10 | ❌162/7⊘3 | ❌166/3⊘3 | both-fail | env-baseline |
| `js/node/tls/node-tls-server.test.ts` | 🔧ohos ⊘0+1 | ❌73/1 | ❌73/1 | both-fail | env-baseline |
| `js/node/tty.test.ts` |  ⊘3+3 | ❌6/1 | ❌6/1 | both-fail | env-baseline |
| `js/node/watch/fs.watch.test.ts` | 🔧ohos ⊘13+13 | ❌38/3⊘11 | ❌41/5⊘6 | both-fail | env-baseline |
| `js/node/os/os.test.js` | 🔧ohos | ❌52/1 | ✅53/0 | A-only-fail |  |
| `js/node/assert/assert-doesNotMatch.test.cjs` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/assert/assert-match.test.cjs` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/assert/assert-promise.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/node/assert/assert-typedarray-deepequal.test.ts` |  | ✅45/0 | ✅45/0 | both-pass |  |
| `js/node/assert/assert.spec.ts` |  | ✅28/0 | ✅28/0 | both-pass |  |
| `js/node/assert/assert.test.cjs` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/node/assert/deep-equal.test.ts` |  | ✅305/0 | ✅305/0 | both-pass |  |
| `js/node/async_hooks/async_hooks.node.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/async_hooks/async-local-storage-thenable.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/async_hooks/AsyncLocalStorage-tracking.test.ts` |  | ✅74/0 | ✅74/0 | both-pass |  |
| `js/node/async_hooks/AsyncLocalStorage.test.ts` |  | ✅47/0 | ✅47/0 | both-pass |  |
| `js/node/async_hooks/EventEmitterAsyncResource.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/buffer-compare-bounds.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `js/node/buffer-concat.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/node/buffer-copy-fill-detach.test.ts` |  | ✅23/0 | ✅23/0 | both-pass |  |
| `js/node/buffer-from-encoding-leak.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/buffer-from-symbol-to-primitive.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/buffer-indexOf-detach.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `js/node/buffer-indexof-worstcase.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/node/buffer-inspectmaxbytes.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/buffer-resolveObjectURL.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/buffer-utf16.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/buffer.test.js` |  ⊘3+3 | ✅673/0 | ✅673/0 | both-pass |  |
| `js/node/child_process/child_process_ipc_handle.test.ts` |  ⊘1+1 | ✅12/0 | ✅12/0 | both-pass |  |
| `js/node/child_process/child_process_ipc_large_disconnect.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/child_process/child_process_ipc.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/child_process/child_process_send_cb.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/child_process/child_process-node.test.js` |  | ✅30/0 | ✅30/0 | both-pass |  |
| `js/node/child_process/child-process-exec.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/node/child_process/child-process-socket-inherit.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/node/child_process/child-process-stdio.test.js` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/node/console/console-constructor-exception.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/console/console-table-iterators.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/console/console.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/node/crypto/crypto-extra-memory.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/node/crypto/crypto-hmac-algorithm.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/crypto/crypto-invalid-this.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/crypto/crypto-lazyhash.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/crypto/crypto-oneshot.test.ts` |  | ✅35/0 | ✅35/0 | both-pass |  |
| `js/node/crypto/crypto-pqc.test.ts` |  | ✅23/0 | ✅23/0 | both-pass |  |
| `js/node/crypto/crypto-random.test.ts` |  ⊘1+1 | ✅17/0⊘8 | ✅17/0⊘8 | both-pass |  |
| `js/node/crypto/crypto-rsa.test.js` |  | ✅22/0 | ✅22/0 | both-pass |  |
| `js/node/crypto/crypto-sign-regression.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/crypto/crypto.hmac.test.ts` |  | ✅74/0 | ✅74/0 | both-pass |  |
| `js/node/crypto/crypto.key-objects.test.ts` |  ⊘2+2 | ✅86/0⊘31 | ✅86/0⊘31 | both-pass |  |
| `js/node/crypto/crypto.test.ts` |  ⊘1+1 | ✅403/0 | ✅403/0 | both-pass |  |
| `js/node/crypto/ecdh.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/node/crypto/hkdf-callback-null.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/crypto/node-crypto.test.js` |  | ✅208/0 | ✅208/0 | both-pass |  |
| `js/node/crypto/pbkdf2.test.ts` |  | ✅45/0 | ✅45/0 | both-pass |  |
| `js/node/crypto/scrypt.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/crypto/sign-jwk-ieee-p1363.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/crypto/x509-subclass.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/node/crypto/x509.test.ts` |  | ✅19/0 | ✅19/0 | both-pass |  |
| `js/node/dgram/node-dgram.test.js` |  ⊘1+1 | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/diagnostics_channel/diagnostics_channel.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/dirname.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/dns/dns-lookup-keepalive.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/dns/dns-resolver-concurrent-timeout.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/dns/dns-tcp-bidirectional-poll.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/domexception-node.test.js` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/node/env-windows.test.ts` |  | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/node/errors/error-code-toString-receiver.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/events/event-emitter.test.ts` |  | ✅75/0 | ✅75/0 | both-pass |  |
| `js/node/fs/abort-signal-leak-read-write-file.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/fs/cp-symlink-target.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/fs/dir.test.ts` |  ⊘1+1 | ✅23/0 | ✅23/0 | both-pass |  |
| `js/node/fs/fs-leak.test.js` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/fs/fs-path-length.test.ts` |  | ✅0/0⊘36 | ✅11/0⊘25 | both-pass |  |
| `js/node/fs/fs-promises-writeFile-async-iterator.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/fs/fs-stat-seccomp-linux.test.ts` |  ⊘1+1 | ✅0/0⊘3 | ✅3/0 | both-pass |  |
| `js/node/fs/fs-stats-constructor.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/fs/fs-stats-truncate.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/fs/fs-write-offset-bound.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/node/fs/fs-writeSync-stdio-windows.test.ts` |  | ✅0/0⊘2 | ✅0/0⊘2 | both-pass |  |
| `js/node/fs/glob.test.ts` |  | ✅34/0 | ✅34/0 | both-pass |  |
| `js/node/fs/promises.test.js` |  ⊘5+5 | ✅30/0⊘5 | ✅30/0⊘5 | both-pass |  |
| `js/node/fs/readdir-windows-ntstatus.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/node/fs/readdirSync-recursive-error-leak.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/fs/rm-windows-ntstatus.test.ts` |  ⊘3+3 | ✅1/0⊘2 | ✅1/0⊘2 | both-pass |  |
| `js/node/fs/translate-uv-error-windows.test.ts` |  ⊘2+2 | ✅1/0⊘1 | ✅1/0⊘1 | both-pass |  |
| `js/node/harness.test.js` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/node/http/client-timeout-error.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/http/early-hints-crlf-injection.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/http/node-fetch-cjs.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/http/node-fetch-primordials.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/http/node-fetch.test.js` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/node/http/node-http-agent-tls-options.test.mts` |  | ✅15/0 | ✅15/0 | both-pass |  |
| `js/node/http/node-http-backpressure-max.test.ts` |  ⊘1+1 | ✅1/0 | ✅0/0⊘1 | both-pass |  |
| `js/node/http/node-http-backpressure.test.ts` | 🔧ohos | ✅19/0 | ✅19/0 | both-pass |  |
| `js/node/http/node-http-client-request-gc.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/http/node-http-maxHeaderSize.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/http/node-http-nested-cork.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/node/http/node-http-ondata-reregister-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/http/node-http-parser.test.ts` |  | ✅16/0 | ✅16/0 | both-pass |  |
| `js/node/http/node-http-pinned-write.test.ts` |  ⊘4+4 | ✅10/0 | ✅10/0 | both-pass |  |
| `js/node/http/node-http-primoridals.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/http/node-http-proxy-url.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/http/node-http-req-socket-pause.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/http/node-http-res-settimeout-unref.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/http/node-http-server-abort-events.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/http/node-http-server-socket-end-drain.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/http/node-http-server-timeouts.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/http/node-http-syscall-fault.test.ts` |  ⊘2+2 | ✅0/0⊘4 | ✅0/0⊘4 | both-pass |  |
| `js/node/http/node-http-transfer-encoding.test.ts` |  | ✅30/0 | ✅30/0 | both-pass |  |
| `js/node/http/node-http-uaf.test.ts` |  | ✅8/0⊘1 | ✅8/0⊘1 | both-pass |  |
| `js/node/http/node-http-with-ws.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/http/node-http.compress.leak.test.ts` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/node/http/node-https-checkServerIdentity.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/http/numeric-header.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/http2/h2-conformance.test.ts` |  | ✅67/0 | ✅67/0 | both-pass |  |
| `js/node/http2/h2-late-rst-staged.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/http2/h2-push-refusal-staged.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/http2/node-http2-continuation.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/node/http2/node-http2-invalid-padding.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/node/http2/node-http2-streams-rehash.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/http2/node-http2-syscall-fault.test.ts` |  ⊘3+3 | ✅0/0⊘10 | ✅0/0⊘10 | both-pass |  |
| `js/node/http2/node-http2-upgrade.test.mts` |  | ✅15/0 | ✅15/0 | both-pass |  |
| `js/node/http2/node-http2.test.js` | 🔧ohos ⊘1+1 | ✅368/0 | ✅368/0 | both-pass |  |
| `js/node/inspector/inspector-profiler.test.ts` |  | ✅45/0 | ✅45/0 | both-pass |  |
| `js/node/inspector/inspector.test.ts` |  | ✅24/0 | ✅24/0 | both-pass |  |
| `js/node/missing-module.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/module/esm-registry-concurrent-gc.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/module/module-children-concurrent-gc.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/module/module-resolve-filename-paths.test.js` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/module/module-sourcemap.test.js` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/module/require-extensions.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/node/module/sourcemap.test.js` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/node/net/blocklist-gc.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/net/connect-autoselectfamily-stale-timer.test.ts` |  | ✅1/0⊘1 | ✅1/0⊘1 | both-pass |  |
| `js/node/net/double-connect.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/net/net-mongodb-pattern-leak.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/net/net-syscall-fault.test.ts` |  ⊘3+3 | ✅0/0⊘21 | ✅0/0⊘21 | both-pass |  |
| `js/node/net/socket-reconnect-live.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/net/socketaddress.spec.ts` |  ⊘1+1 | ✅66/0⊘1 | ✅66/0⊘1 | both-pass |  |
| `js/node/no-addons.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/nodettywrap.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/path/15704.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/path/basename.test.js` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/path/browserify.test.js` |  | ✅52/0 | ✅52/0 | both-pass |  |
| `js/node/path/dirname.test.js` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/path/extname.test.js` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/path/is-absolute.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/path/join.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/path/matches-glob.test.ts` |  | ✅31/0 | ✅31/0 | both-pass |  |
| `js/node/path/normalize.test.js` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/path/parse-format.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/path/path.test.js` |  | ✅4/0⊘1 | ✅4/0⊘1 | both-pass |  |
| `js/node/path/posix-exists.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/path/posix-relative-on-windows.test.js` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/node/path/relative.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/path/resolve-long-cwd.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/path/resolve.test.js` |  ⊘2+2 | ✅5/0⊘1 | ✅5/0⊘1 | both-pass |  |
| `js/node/path/to-namespaced-path.test.js` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/path/win32-exists.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/path/zero-length-strings.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/perf_hooks/perf_hooks.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/node/process-binding.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/process/call-constructor.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/process/process-args.test.js` |  ⊘1+1 | ✅7/0⊘2 | ✅7/0⊘2 | both-pass |  |
| `js/node/process/process-array-accessor-crash.test.ts` |  ⊘1+1 | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/process/process-execve.test.ts` |  ⊘10+10 | ✅10/0⊘1 | ✅10/0⊘1 | both-pass |  |
| `js/node/process/process-memory-pressure.test.ts` |  ⊘2+2 | ✅5/0⊘2 | ✅6/0⊘1 | both-pass |  |
| `js/node/process/process-nexttick.test.js` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/node/process/process-on.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/process/process-signal-listener-count.test.ts` |  ⊘3+3 | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/process/process-signal-windows.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/node/process/process-stdio-invalid-utf16.test.ts` |  | ✅24/0 | ✅24/0 | both-pass |  |
| `js/node/process/process-stdio-stack-overflow.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/process/process-stdio.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/node/process/process-stdout-write-after-end.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/process/stdin/stdin-fixtures.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/promise/reject-tostring.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/quic/quic-endpoint.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/node/quic/quic-sni.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/quic/quic-stream.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/readline/getStringWidth.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/readline/pause_stdin_should_exit.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/readline/readline_never_unrefs.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/readline/readline_promises.node.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/readline/readline.node.test.ts` |  | ✅80/0 | ✅80/0 | both-pass |  |
| `js/node/readline/stdin_fell_asleep.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/readline/stdin-pause-pty.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/sqlite/node-sqlite.test.ts` |  ⊘14+14 | ✅115/0⊘4 | ✅115/0⊘4 | both-pass |  |
| `js/node/stream/node-stream-uint8array.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/stream/node-stream.test.js` |  | ✅103/0⊘1 | ✅103/0⊘1 | both-pass |  |
| `js/node/string_decoder/string-decoder.test.js` |  | ✅98/0 | ✅98/0 | both-pass |  |
| `js/node/string-module.test.js` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/stubs.test.js` |  | ✅378/0 | ✅378/0 | both-pass |  |
| `js/node/test_runner/node-test.test.ts` |  ⊘2+2 | ✅45/0 | ✅45/0 | both-pass |  |
| `js/node/timers.promises/timers.promises.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/node/timers/node-timers.test.ts` |  | ✅23/0 | ✅23/0 | both-pass |  |
| `js/node/tls/fetch-tls-cert.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/node/tls/node-tls-cert.test.ts` |  | ✅28/0 | ✅28/0 | both-pass |  |
| `js/node/tls/node-tls-connect-hostname-verification.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/node/tls/node-tls-connect.test.ts` |  ⊘2+2 | ✅60/0⊘1 | ✅60/0⊘1 | both-pass |  |
| `js/node/tls/node-tls-context.test.ts` |  | ✅17/0 | ✅17/0 | both-pass |  |
| `js/node/tls/node-tls-create-secure-context-args.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/node/tls/node-tls-duplex-close-throw-uaf.test.ts` |  | ✅0/0⊘2 | ✅0/0⊘2 | both-pass |  |
| `js/node/tls/node-tls-duplex-write-throw-error-value.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/tls/node-tls-ecdh-curve.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/tls/node-tls-getpeercert-leak.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/tls/node-tls-internals.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/tls/node-tls-namedpipes.test.ts` |  | ✅0/0⊘6 | ✅0/0⊘6 | both-pass |  |
| `js/node/tls/node-tls-no-cipher-match-error.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/tls/node-tls-root-certs-concurrent-init.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/tls/node-tls-rootcertificates-immutable.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/tls/node-tls-socket-allow-half-open-option.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/tls/node-tls-upgrade.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/tls/renegotiation.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/node/tls/ssl-ctx-cache.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/node/tls/test-node-extra-ca-certs.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/tls/test-system-ca-https.test.ts` |  ⊘1+1 | ✅0/0⊘2 | ✅0/0⊘2 | both-pass |  |
| `js/node/tls/test-use-system-ca.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/tls/tls-connect-socket-churn.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/tls/tls-syscall-fault.test.ts` |  ⊘4+4 | ✅0/0⊘12 | ✅0/0⊘12 | both-pass |  |
| `js/node/trace_events/trace-events.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/url/pathToFileURL.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/url/url-canParse-whatwg.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/url/url-domain-ascii-unicode.test.js` |  | ✅130/0 | ✅130/0 | both-pass |  |
| `js/node/url/url-fileurltopath.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/url/url-fileurltopathbuffer.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/node/url/url-format-invalid-input.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/url/url-format-whatwg.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/url/url-format.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/url/url-is-url.test.js` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/node/url/url-null-char.test.js` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/node/url/url-parse-format.test.js` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/url/url-parse-invalid-input.test.js` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/node/url/url-parse-ipv6.test.ts` |  | ✅34/0 | ✅34/0 | both-pass |  |
| `js/node/url/url-parse-query.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/url/url-pathtofileurl.test.js` |  ⊘1+1 | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/url/url-relative.test.js` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/url/url-revokeobjecturl.test.js` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/node/url/url.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/util/bun-inspect.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/node/util/custom-inspect.test.js` |  | ✅44/0 | ✅44/0 | both-pass |  |
| `js/node/util/mime-api.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/node/util/node-inspect-tests/import.test.mjs` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/util/node-inspect-tests/internal-inspect.test.js` |  ⊘1+1 | ✅2/0⊘1 | ✅2/0⊘1 | both-pass |  |
| `js/node/util/node-inspect-tests/parallel/util-format.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/util/node-inspect-tests/parallel/util-inspect-getters-accessing-this.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/util/node-inspect-tests/parallel/util-inspect-long-running.test.mjs` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/util/node-inspect-tests/parallel/util-inspect-proxy.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/util/node-inspect-tests/parallel/util-inspect.test.js` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/util/parse_args/default-args.test.mjs` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/node/util/parse_args/parse-args-null-config.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/node/util/parse_args/parse-args-token-key-order.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/util/parse_args/parse-args.test.mjs` |  | ✅108/0 | ✅108/0 | both-pass |  |
| `js/node/util/test-aborted.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/util/test-util-types.test.js` |  | ✅53/0 | ✅53/0 | both-pass |  |
| `js/node/util/util-callbackify.test.js` |  | ✅90/0 | ✅90/0 | both-pass |  |
| `js/node/util/util-promisify.test.js` |  ⊘1+1 | ✅16/0⊘1 | ✅16/0⊘1 | both-pass |  |
| `js/node/util/util.test.js` |  | ✅209/0 | ✅209/0 | both-pass |  |
| `js/node/v8/capture-stack-trace.test.js` |  | ✅44/0 | ✅44/0 | both-pass |  |
| `js/node/v8/v8-date-parser.test.js` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/v8/v8-module.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/node/v8/v8-serdes-buffer.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/node/vm/happy-dom-vm-16277.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/vm/script-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/vm/sourcetextmodule-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/vm/sourcetextmodule-link-gc.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/vm/vm-script-fetcher-leak.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/vm/vm-sourceUrl.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/vm/vm.test.ts` |  ⊘3+3 | ✅276/0⊘2 | ✅276/0⊘2 | both-pass |  |
| `js/node/watch/fs.watch.close-exit.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/watch/fs.watch.deadlock.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/watch/fs.watch.events-cb-race.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/node/watch/fs.watch.rewrite.test.ts` |  ⊘4+4 | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/watch/fs.watchFile.test.ts` |  ⊘1+1 | ✅10/0⊘2 | ✅10/0⊘2 | both-pass |  |
| `js/node/worker_threads/15787.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/worker_threads/worker_destruction.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/worker_threads/worker_heap_snapshot_gc.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/worker_threads/worker_threads.test.ts` |  | ✅137/0 | ✅137/0 | both-pass |  |
| `js/node/worker_threads/worker-async-dispose.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/worker_threads/worker-shutdown-post-leak.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/node/worker_threads/worker-top-level-await.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/worker_threads/worker-transfer-list.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/node/worker_threads/worker-transfer-terminate-stress.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/zlib/bytesWritten.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/zlib/deflate-streaming.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/node/zlib/leak.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/node/zlib/zlib-estimated-size-gc.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/node/zlib/zlib-handle-bounds-check.test.ts` |  | ✅39/0 | ✅39/0 | both-pass |  |
| `js/node/zlib/zlib-onerror-reentrancy.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/node/zlib/zlib-reset-race.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/node/zlib/zlib.kMaxLength.global.test.js` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/node/zlib/zlib.test.js` |  ⊘1+1 | ✅388/0⊘2 | ✅388/0⊘2 | both-pass |  |

## Web 标准 API（175 文件 / 13 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `js/web/fetch/fetch-tcp-keepalive.test.ts` |  ⊘2+2 | ✅0/0⊘7 | ❌1/6 | B-only-fail |  |
| `js/web/intl/intl.test.ts` |  ⊘1+1 | ✅32/0⊘1 | ❌32/1 | B-only-fail |  |
| `js/web/websocket/autobahn.test.ts` |  ⊘1+1 | ✅0/0⊘3 | ❌0/1 | B-only-fail |  |
| `js/web/websocket/websocket-proxy.test.ts` |  ⊘1+1 | ✅34/0⊘4 | ❌0/1 | B-only-fail |  |
| `js/web/workers/structured-clone.test.ts` |  | ✅231/0 | ❌228/3 | B-only-fail |  |
| `js/web/workers/structuredClone-classes.test.ts` |  | ✅57/0 | ❌54/3 | B-only-fail |  |
| `js/web/fetch/fetch.test.ts` |  ⊘4+4 | ❌357/5 | ❌357/5 | both-fail | env-baseline |
| `js/web/fetch/fetch.tls.test.ts` |  | ❌29/1 | ❌29/1 | both-fail | env-baseline |
| `js/web/fetch/fetch.unix.test.ts` | 🔧ohos | ❌1/5 | ❌3/6 | both-fail | env-baseline |
| `js/web/streams/streams.test.js` |  | ❌174/1 | ❌174/1 | both-fail | env-baseline |
| `js/web/websocket/websocket-unix.test.ts` |  ⊘1+1 | ❌2/5 | ❌2/5 | both-fail | env-baseline |
| `js/web/workers/message-port-context-destroy-leak.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/web/workers/worker-late-completion.test.ts` |  ⊘3+3 | ❌0/4⊘29 | ❌0/4⊘29 | both-fail | env-baseline |
| `js/web/abort/abort-controller-gc-reason.test.ts` |  ⊘2+2 | ✅6/0 | ✅6/0 | both-pass |  |
| `js/web/abort/abort-signal-event-listener-leak.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/web/abort/abort.test.ts` |  | ✅16/0 | ✅16/0 | both-pass |  |
| `js/web/atomics.test.ts` |  | ✅28/0 | ✅28/0 | both-pass |  |
| `js/web/broadcastchannel/broadcast-channel-worker-gc.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/web/broadcastchannel/broadcast-channel.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/web/broadcastchannel/message-event-init-gc.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/console/console-log-utf16.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/console/console-log.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/web/console/console-recursive.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/console/console-timeLog.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/web/crypto/web-crypto-sha3.test.ts` |  | ✅17/0 | ✅17/0 | both-pass |  |
| `js/web/crypto/web-crypto.test.ts` |  | ✅94/0 | ✅94/0 | both-pass |  |
| `js/web/encoding/encode-bad-chunks.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/web/encoding/text-decoder-cjk.test.ts` |  | ✅58/0 | ✅58/0 | both-pass |  |
| `js/web/encoding/text-decoder-single-byte.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/web/encoding/text-decoder-stream.test.ts` |  | ✅51/0 | ✅51/0 | both-pass |  |
| `js/web/encoding/text-decoder-wpt.test.ts` |  | ✅281/0 | ✅281/0 | both-pass |  |
| `js/web/encoding/text-decoder.test.js` |  | ✅125/0 | ✅125/0 | both-pass |  |
| `js/web/encoding/text-encoder-stream.test.ts` |  | ✅24/0 | ✅24/0 | both-pass |  |
| `js/web/encoding/text-encoder.test.js` |  | ✅42/0 | ✅42/0 | both-pass |  |
| `js/web/explicit-resource-management.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/web/fetch/abort-signal-leak.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/web/fetch/blob-array-fast-path.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/web/fetch/blob-cow.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/web/fetch/blob-file-name-ownership.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/fetch/blob-oom.test.ts` |  ⊘2+2 | ✅20/0 | ✅20/0 | both-pass |  |
| `js/web/fetch/blob-write.test.ts` |  | ✅15/0 | ✅15/0 | both-pass |  |
| `js/web/fetch/blob.test.ts` |  ⊘1+1 | ✅102/0⊘2 | ✅102/0⊘2 | both-pass |  |
| `js/web/fetch/body-async-iterator.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/fetch/body-clone.test.ts` |  | ✅63/0 | ✅63/0 | both-pass |  |
| `js/web/fetch/body-mixin-errors.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/web/fetch/body-stream-excess.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/web/fetch/body-stream.test.ts` |  | ✅9086/0 | ✅9086/0 | both-pass |  |
| `js/web/fetch/body.test.ts` |  | ✅459/0⊘4 | ✅459/0⊘4 | both-pass |  |
| `js/web/fetch/chunked-trailing.test.js` |  | ✅23/0 | ✅23/0 | both-pass |  |
| `js/web/fetch/client-fetch.test.ts` |  | ✅34/0 | ✅34/0 | both-pass |  |
| `js/web/fetch/content-length.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/fetch/cookies.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/web/fetch/encoding.test.ts` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `js/web/fetch/exiting.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/fetch/fetch_headers.test.js` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/web/fetch/fetch-abort-queued.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/fetch/fetch-abort-socket-close-race.test.ts` |  ⊘2+2 | ✅0/0⊘2 | ✅0/0⊘2 | both-pass |  |
| `js/web/fetch/fetch-abort-stream-body.test.ts` |  ⊘1+1 | ✅4/0⊘3 | ✅4/0⊘3 | both-pass |  |
| `js/web/fetch/fetch-args.test.ts` |  | ✅61/0 | ✅61/0 | both-pass |  |
| `js/web/fetch/fetch-backpressure.test.ts` |  ⊘2+2 | ✅53/0⊘1 | ✅54/0 | both-pass |  |
| `js/web/fetch/fetch-compress.test.ts` |  ⊘1+1 | ✅32/0 | ✅32/0 | both-pass |  |
| `js/web/fetch/fetch-connection-header.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/web/fetch/fetch-cyclic-reference.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/fetch/fetch-gzip.test.ts` |  | ✅80/0 | ✅80/0 | both-pass |  |
| `js/web/fetch/fetch-header-str-bounds.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/fetch/fetch-http2-adversarial.test.ts` |  | ✅20/0 | ✅20/0 | both-pass |  |
| `js/web/fetch/fetch-http2-client.test.ts` |  | ✅62/0 | ✅62/0 | both-pass |  |
| `js/web/fetch/fetch-http2-leak.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/web/fetch/fetch-http3-adversarial.test.ts` |  | ✅27/0 | ✅27/0 | both-pass |  |
| `js/web/fetch/fetch-http3-client.test.ts` |  | ✅53/0 | ✅53/0 | both-pass |  |
| `js/web/fetch/fetch-http3-cold-post.test.ts` |  ⊘1+1 | ✅1/0⊘1 | ✅1/0⊘1 | both-pass |  |
| `js/web/fetch/fetch-http3-syscall-fault.test.ts` |  ⊘3+3 | ✅0/0⊘3 | ✅0/0⊘3 | both-pass |  |
| `js/web/fetch/fetch-keepalive.test.ts` |  | ✅36/0 | ✅36/0 | both-pass |  |
| `js/web/fetch/fetch-leak.test.ts` |  | ✅29/0 | ✅29/0 | both-pass |  |
| `js/web/fetch/fetch-preconnect.test.ts` |  ⊘1+1 | ✅13/0⊘1 | ✅13/0⊘1 | both-pass |  |
| `js/web/fetch/fetch-proxy-connect-tunnel-split-envelope.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/web/fetch/fetch-proxy-tls-intern-race.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/fetch/fetch-redirect.test.ts` |  | ✅30/0 | ✅30/0 | both-pass |  |
| `js/web/fetch/fetch-response-finalizer-sweep.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/fetch/fetch-retry-chunked.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/fetch/fetch-stream-cancel-leak.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/web/fetch/fetch-syscall-fault.test.ts` |  ⊘3+3 | ✅0/0⊘13 | ✅0/0⊘13 | both-pass |  |
| `js/web/fetch/fetch-tcp-stress.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/web/fetch/fetch-tls-abortsignal-timeout.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/web/fetch/fetch-url-after-redirect.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/fetch/fetch.brotli.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/fetch/fetch.stream.test.ts` |  ⊘1+1 | ✅117/0 | ✅117/0 | both-pass |  |
| `js/web/fetch/fetch.tls.wildcard.test.ts` |  | ✅72/0 | ✅72/0 | both-pass |  |
| `js/web/fetch/fetch.upgrade.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/fetch/form-data-boundary-crash.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/web/fetch/headers-case.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/web/fetch/headers.test.ts` |  | ✅99/0 | ✅99/0 | both-pass |  |
| `js/web/fetch/headers.undici.test.ts` |  | ✅51/0 | ✅51/0 | both-pass |  |
| `js/web/fetch/request-cyclic-reference.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/fetch/response-cyclic-reference.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/fetch/response.test.ts` |  | ✅23/0 | ✅23/0 | both-pass |  |
| `js/web/fetch/server-response-stream-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/fetch/stream-fast-path.test.ts` |  | ✅75/0 | ✅75/0 | both-pass |  |
| `js/web/fetch/utf8-bom.test.ts` |  | ✅21/0 | ✅21/0 | both-pass |  |
| `js/web/fetch/wasm-streaming.test.ts` |  | ✅33/0 | ✅33/0 | both-pass |  |
| `js/web/fetch/wpt/textstream-wpt.test.ts` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/web/html/FormData-file-error-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/html/FormData-multipart-serialization.test.ts` |  ⊘1+1 | ✅5/0⊘1 | ✅6/0 | both-pass |  |
| `js/web/html/FormData.test.ts` |  | ✅149/0 | ✅149/0 | both-pass |  |
| `js/web/html/html-rewriter-doctype.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/html/URLSearchParams.test.ts` |  | ✅17/0 | ✅17/0 | both-pass |  |
| `js/web/nationalized.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/request/request-clone-leak.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/web/request/request-method-getter.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/web/request/request-subclass.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/request/request.test.ts` |  | ✅19/0 | ✅19/0 | both-pass |  |
| `js/web/streams/compression.test.ts` |  ⊘1+1 | ✅64/0⊘1 | ✅64/0⊘1 | both-pass |  |
| `js/web/streams/native-source-onclose-leak.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/web/streams/pipeTo-shutdown-gc.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/streams/pipeTo-signal-leak.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/streams/readable-stream-blob-consumed.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/streams/readable-stream-terminal-barrier-release.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/streams/streams-leak.test.ts` |  ⊘2+2 | ✅3/0 | ✅3/0 | both-pass |  |
| `js/web/streams/streams-string-limit.test.ts` |  ⊘1+1 | ✅6/0 | ✅6/0 | both-pass |  |
| `js/web/streams/sync-pull-fast-path.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/web/streams/transform-stream-leak.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/web/structured-clone-blob-file.test.ts` |  ⊘1+1 | ✅42/0 | ✅42/0 | both-pass |  |
| `js/web/structured-clone-fastpath.test.ts` |  | ✅92/0 | ✅92/0 | both-pass |  |
| `js/web/structured-clone-shared-array-buffer.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/web/temporal/temporal.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/web/timers/clearImmediate-gc.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/timers/microtask.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/timers/performance-entries.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/timers/performance.test.js` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/web/timers/setImmediate.test.js` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/web/timers/setImmediate2.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/timers/setInterval.test.js` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/web/timers/setTimeout.test.js` |  ⊘3+3 | ✅33/0⊘3 | ✅36/0 | both-pass |  |
| `js/web/timers/timer-gc-roots.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/web/timers/timer-heap-race.test.ts` |  ⊘2+2 | ✅1/0⊘2 | ✅1/0⊘2 | both-pass |  |
| `js/web/url/url-wpt-constructor.test.ts` |  | ✅870/0 | ✅870/0 | both-pass |  |
| `js/web/url/url.test.ts` | 🔧适配 ⊘1+1 | ✅27/0 | ✅27/0 | both-pass |  |
| `js/web/url/url.windows.test.js` |  | ✅0/0⊘16 | ✅0/0⊘16 | both-pass |  |
| `js/web/urlpattern/urlpattern.test.ts` |  | ✅408/0 | ✅408/0 | both-pass |  |
| `js/web/util/atob.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/web-globals.test.js` |  | ✅23/0 | ✅23/0 | both-pass |  |
| `js/web/websocket/error-event.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/websocket/test-ws-bidir-proxy.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/websocket/websocket-accept-header-validation.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/websocket/websocket-blob.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/web/websocket/websocket-client-short-read.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/web/websocket/websocket-client.test.ts` |  | ✅37/0 | ✅37/0 | both-pass |  |
| `js/web/websocket/websocket-close-async-dispatch.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/web/websocket/websocket-close-code.test.ts` |  | ✅24/0 | ✅24/0 | both-pass |  |
| `js/web/websocket/websocket-close-connecting.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/web/websocket/websocket-close-fragmented.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/websocket/websocket-custom-headers.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/web/websocket/websocket-handshake-event.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/websocket/websocket-permessage-deflate-edge-cases.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/web/websocket/websocket-permessage-deflate-simple.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/web/websocket/websocket-permessage-deflate.test.ts` |  ⊘1+1 | ✅8/0⊘1 | ✅8/0⊘1 | both-pass |  |
| `js/web/websocket/websocket-pong-fragmented.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/web/websocket/websocket-proxy-close-reentrancy.test.ts` |  ⊘1+1 | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/websocket/websocket-proxy-tunnel-client-leak.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/web/websocket/websocket-proxy-tunnel-upgrade-leak.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/web/websocket/websocket-subprotocol-strict.test.ts` |  | ✅19/0 | ✅19/0 | both-pass |  |
| `js/web/websocket/websocket-syscall-fault.test.ts` |  | ✅0/0⊘15 | ✅0/0⊘15 | both-pass |  |
| `js/web/websocket/websocket-upgrade.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/web/websocket/websocket-utf16-headers.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/web/websocket/websocket.test.js` |  | ✅48/0 | ✅48/0 | both-pass |  |
| `js/web/workers/message-channel.test.ts` |  | ✅17/0 | ✅17/0 | both-pass |  |
| `js/web/workers/message-event.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/web/workers/message-port-closed-leak.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/web/workers/message-port-pipe.test.ts` |  ⊘3+3 | ✅10/0⊘3 | ✅10/0⊘3 | both-pass |  |
| `js/web/workers/performance-observer-leak.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/web/workers/worker_blob.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/web/workers/worker-postmessage-transfer.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/web/workers/worker-terminate-funnels.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/web/workers/worker-terminate-lifetime.test.ts` |  ⊘10+10 | ✅14/0⊘11 | ✅14/0⊘11 | both-pass |  |
| `js/web/workers/worker.test.ts` |  | ✅37/0 | ✅37/0 | both-pass |  |

## 第三方库兼容（120 文件 / 17 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `js/third_party/@azure/service-bus/azure-service-bus.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/@napi-rs/canvas/napi-rs-canvas.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/astro/astro-post.test.js` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/esbuild/esbuild-child_process.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/grpc-js/test-idle-timer.test.ts` |  | ❌7/1 | ❌7/1 | both-fail | env-baseline |
| `js/third_party/grpc-js/test-resolver.test.ts` |  ⊘6+6 | ❌18/2⊘3 | ❌18/2⊘3 | both-fail | env-baseline |
| `js/third_party/mongodb/mongodb.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/next-auth/next-auth.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/nodemailer/nodemailer.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/pg/pg.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/pnpm/pnpm.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/postgres/postgres.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/prisma/prisma.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/resvg/bbox.test.js` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/rollup-v4/rollup-v4.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/stripe/stripe.test.ts` |  ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `js/third_party/vitest/vitest.test.ts` |  | ❌0/2 | ❌0/2 | both-fail | env-baseline |
| `js/third_party/@electric-sql/pglite/pglite.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/@fastify/websocket/fastity-test-websocket.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/body-parser/express-body-parser-test.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/third_party/body-parser/express-bun-build-compile.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/body-parser/express-memory-leak.test.ts` |  ⊘1+1 | ✅4/0 | ✅4/0 | both-pass |  |
| `js/third_party/comlink/comlink.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/es-module-lexer/es-module-lexer.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/express/app.router.test.ts` |  ⊘1+1 | ✅77/0 | ✅77/0 | both-pass |  |
| `js/third_party/express/express.json.test.ts` |  ⊘1+1 | ✅47/0⊘3 | ✅47/0⊘3 | both-pass |  |
| `js/third_party/express/express.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/express/express.text.test.ts` |  | ✅33/0 | ✅33/0 | both-pass |  |
| `js/third_party/express/res.json.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `js/third_party/express/res.location.test.ts` |  | ✅12/0 | ✅12/0 | both-pass |  |
| `js/third_party/express/res.redirect.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/third_party/express/res.send.test.ts` |  ⊘1+1 | ✅65/0 | ✅65/0 | both-pass |  |
| `js/third_party/express/res.sendFile.test.ts` |  | ✅39/0 | ✅39/0 | both-pass |  |
| `js/third_party/grpc-js/test-call-credentials.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/third_party/grpc-js/test-call-propagation.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/third_party/grpc-js/test-certificate-provider.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/third_party/grpc-js/test-channel-credentials.test.ts` |  | ✅9/0 | ✅9/0 | both-pass |  |
| `js/third_party/grpc-js/test-channelz.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/third_party/grpc-js/test-client.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/third_party/grpc-js/test-confg-parsing.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/third_party/grpc-js/test-deadline.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/third_party/grpc-js/test-duration.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/third_party/grpc-js/test-end-to-end.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `js/third_party/grpc-js/test-global-subchannel-pool.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/third_party/grpc-js/test-local-subchannel-pool.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/grpc-js/test-logging.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/third_party/grpc-js/test-metadata.test.ts` |  | ✅29/0 | ✅29/0 | both-pass |  |
| `js/third_party/grpc-js/test-outlier-detection.test.ts` |  | ✅26/0 | ✅26/0 | both-pass |  |
| `js/third_party/grpc-js/test-pick-first.test.ts` |  | ✅22/0 | ✅22/0 | both-pass |  |
| `js/third_party/grpc-js/test-prototype-pollution.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/third_party/grpc-js/test-retry-config.test.ts` |  | ✅28/0 | ✅28/0 | both-pass |  |
| `js/third_party/grpc-js/test-retry.test.ts` |  | ✅15/0 | ✅15/0 | both-pass |  |
| `js/third_party/grpc-js/test-server-credentials.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/third_party/grpc-js/test-server-deadlines.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/third_party/grpc-js/test-server-errors.test.ts` |  | ✅34/0 | ✅34/0 | both-pass |  |
| `js/third_party/grpc-js/test-server-interceptors.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/third_party/grpc-js/test-server.test.ts` |  ⊘2+2 | ✅45/0⊘2 | ✅45/0⊘2 | both-pass |  |
| `js/third_party/grpc-js/test-status-builder.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/third_party/grpc-js/test-tonic.test.ts` |  ⊘1+1 | ✅0/0⊘3 | ✅0/0⊘3 | both-pass |  |
| `js/third_party/grpc-js/test-uri-parser.test.ts` |  | ✅15/0 | ✅15/0 | both-pass |  |
| `js/third_party/hono/hello-world-fixture.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/hono/hello-world.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/http2-wrapper/http2-wrapper.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/jsonwebtoken/async_sign.test.js` |  ⊘1+1 | ✅16/0⊘1 | ✅16/0⊘1 | both-pass |  |
| `js/third_party/jsonwebtoken/buffer.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/jsonwebtoken/claim-aud.test.js` |  | ✅60/0 | ✅60/0 | both-pass |  |
| `js/third_party/jsonwebtoken/claim-exp.test.js` |  | ✅58/0 | ✅58/0 | both-pass |  |
| `js/third_party/jsonwebtoken/claim-iat.test.js` |  | ✅39/0 | ✅39/0 | both-pass |  |
| `js/third_party/jsonwebtoken/claim-iss.test.js` |  | ✅28/0 | ✅28/0 | both-pass |  |
| `js/third_party/jsonwebtoken/claim-jti.test.js` |  | ✅24/0 | ✅24/0 | both-pass |  |
| `js/third_party/jsonwebtoken/claim-nbf.test.js` |  | ✅58/0 | ✅58/0 | both-pass |  |
| `js/third_party/jsonwebtoken/claim-private.test.js` |  | ✅19/0 | ✅19/0 | both-pass |  |
| `js/third_party/jsonwebtoken/claim-sub.test.js` |  | ✅24/0 | ✅24/0 | both-pass |  |
| `js/third_party/jsonwebtoken/decoding.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/jsonwebtoken/encoding.test.js` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/third_party/jsonwebtoken/expires_format.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/jsonwebtoken/header-kid.test.js` |  | ✅20/0 | ✅20/0 | both-pass |  |
| `js/third_party/jsonwebtoken/invalid_exp.test.js` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/third_party/jsonwebtoken/issue_147.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/jsonwebtoken/issue_304.test.js` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/third_party/jsonwebtoken/issue_70.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/jsonwebtoken/jwt.asymmetric_signing.test.js` |  | ✅36/0 | ✅36/0 | both-pass |  |
| `js/third_party/jsonwebtoken/jwt.hs.test.js` |  | ✅14/0 | ✅14/0 | both-pass |  |
| `js/third_party/jsonwebtoken/jwt.malicious.test.js` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `js/third_party/jsonwebtoken/non_object_values.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/third_party/jsonwebtoken/noTimestamp.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/jsonwebtoken/option-complete.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/third_party/jsonwebtoken/option-maxAge.test.js` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/third_party/jsonwebtoken/option-nonce.test.js` |  | ✅18/0 | ✅18/0 | both-pass |  |
| `js/third_party/jsonwebtoken/rsa-public-key.test.js` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/third_party/jsonwebtoken/schema.test.js` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `js/third_party/jsonwebtoken/set_headers.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/third_party/jsonwebtoken/undefined_secretOrPublickey.test.js` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/third_party/jsonwebtoken/validateAsymmetricKey.test.js` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `js/third_party/jsonwebtoken/verify.test.js` |  | ✅19/0 | ✅19/0 | both-pass |  |
| `js/third_party/jsonwebtoken/wrong_alg.test.js` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/third_party/msw/msw.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/pg-gateway/pglite.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/pino/pino.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/prompts/prompts.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/remix/remix.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/socket.io/socket.io-close.test.ts` |  ⊘4+4 | ✅2/0⊘4 | ✅2/0⊘4 | both-pass |  |
| `js/third_party/socket.io/socket.io-connection-state-recovery.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `js/third_party/socket.io/socket.io-handshake.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/third_party/socket.io/socket.io-messaging-many.test.ts` |  ⊘12+12 | ✅0/0⊘20 | ✅0/0⊘20 | both-pass |  |
| `js/third_party/socket.io/socket.io-middleware.test.ts` |  ⊘2+2 | ✅0/0⊘10 | ✅0/0⊘10 | both-pass |  |
| `js/third_party/socket.io/socket.io-namespaces.test.ts` |  ⊘12+12 | ✅0/0⊘38 | ✅0/0⊘38 | both-pass |  |
| `js/third_party/socket.io/socket.io-server-attachment.test.ts` |  ⊘2+2 | ✅0/0⊘17 | ✅0/0⊘17 | both-pass |  |
| `js/third_party/socket.io/socket.io-socket-middleware.test.ts` |  ⊘2+2 | ✅0/0⊘2 | ✅0/0⊘2 | both-pass |  |
| `js/third_party/socket.io/socket.io-socket-timeout.test.ts` |  ⊘1+1 | ✅0/0⊘5 | ✅0/0⊘5 | both-pass |  |
| `js/third_party/socket.io/socket.io-utility-methods.test.ts` |  ⊘9+9 | ✅0/0⊘9 | ✅0/0⊘9 | both-pass |  |
| `js/third_party/socket.io/socket.io.test.ts` |  ⊘21+21 | ✅0/0⊘61 | ✅0/0⊘61 | both-pass |  |
| `js/third_party/solc/solc.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/st/st.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/third_party/svelte/svelte.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `js/third_party/undici-h2/run.test.ts` |  | ✅11/0 | ✅11/0 | both-pass |  |
| `js/third_party/webpack/webpack.test.ts` |  ⊘2+2 | ✅0/0⊘2 | ✅0/0⊘2 | both-pass |  |
| `js/third_party/wpt-h2/run.test.ts` |  | ✅20/0 | ✅20/0 | both-pass |  |
| `js/third_party/wpt-streams/wpt-streams.test.ts` |  | ✅1175/0 | ✅1175/0 | both-pass |  |
| `js/third_party/yargs/yargs-cjs.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |

## 端到端集成（22 文件 / 11 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `integration/expo-app/expo.test.ts` | ⏱超时预算 | ✅1/0 | ⏰ | B-only-fail |  |
| `integration/mysql2/mysql2.test.ts` |  | ✅0/0 | ❌0/0 | B-only-fail |  |
| `integration/bun-types/bun-types.test.ts` |  ⊘2+2 | ❌5/10 | ❌2/13 | both-fail | env-baseline |
| `integration/bun-types/fixture/serve-types.test.ts` |  ⊘1+1 | ❌44/9 | ❌44/9 | both-fail | env-baseline |
| `integration/datadog-pprof/datadog-pprof.test.ts` | 🔧ohos ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `integration/esbuild/esbuild.test.ts` | 🔧ohos ⊘1+1 | ❌0/2 | ❌1/1 | both-fail | env-baseline |
| `integration/next-pages/test/dev-server-ssr-100.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `integration/next-pages/test/dev-server.test.ts` |  ⊘1+1 | ❌0/1 | ⏰ | both-fail | env-baseline |
| `integration/next-pages/test/next-build.test.ts` |  | ❌0/1 | ⏰ | both-fail | env-baseline |
| `integration/sharp/sharp.test.ts` |  | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `integration/vite-build/vite-build.test.ts` | 🔧ohos | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `integration/bun-lambda/bun-lambda.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `integration/bun-types/fixture/23347.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `integration/bun-types/fixture/5396.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `integration/jsdom/jsdom.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `integration/nest/nest_metadata.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `integration/sass/sass.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `integration/svelte/client-side.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `integration/svelte/server-side.test.ts` |  | ✅0/0 | ✅0/0 | both-pass |  |
| `integration/typegraphql/src/ts_example.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `integration/typegraphql/src/typegraphql.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `integration/typegraphql/src/unsolvable.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |

## 构建系统/内部（41 文件 / 9 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `internal/build-rust-toolchain-probe.test.ts` | 🔧ohos ⊘1+1 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `internal/oxlint-plugin-bun.test.ts` |  | ❌0/6 | ❌0/6 | both-fail | env-baseline |
| `internal/build-codegen-declared-outputs.test.ts` |  | ❌0/4 | ✅4/0 | A-only-fail |  |
| `internal/build-debug-info-flags.test.ts` |  ⊘1+1 | ❌0/4 | ✅4/0 | A-only-fail |  |
| `internal/build-post-link-ordering.test.ts` |  ⊘1+1 | ❌0/3 | ✅3/0 | A-only-fail |  |
| `internal/macos-cross-config.test.ts` |  ⊘1+1 | ❌5/15 | ✅20/0 | A-only-fail |  |
| `internal/source-lints/build-rust.test.ts` | 🔧ohos | ❌2/6 | ✅8/0 | A-only-fail |  |
| `internal/source-lints/webkit-prebuilt-url.test.ts` |  | ❌1/6 | ✅7/0 | A-only-fail |  |
| `internal/source-lints/windows-cross-config.test.ts` |  ⊘1+1 | ❌0/8 | ✅8/0 | A-only-fail |  |
| `internal/bindgen.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `internal/build-download-retry.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `internal/fifo.test.ts` |  | ✅26/0 | ✅26/0 | both-pass |  |
| `internal/highlighter.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `internal/int_from_float.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `internal/internal-module-blob.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `internal/linear-fifo.test.ts` |  ⊘1+1 | ✅2/0⊘1 | ✅2/0⊘1 | both-pass |  |
| `internal/parallel-allowlist.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `internal/powershell-escape.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `internal/rust-check-all.test.ts` |  ⊘1+1 | ✅4/0 | ✅4/0 | both-pass |  |
| `internal/rust-windows-sys-link.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅0/0⊘1 | both-pass |  |
| `internal/sigaction-layout.test.ts` |  ⊘1+1 | ✅0/0⊘1 | ✅1/0 | both-pass |  |
| `internal/source-lints/byte-search.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `internal/source-lints/ci-annotations.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `internal/source-lints/dead-code-escapes.test.ts` |  | ✅23/0 | ✅23/0 | both-pass |  |
| `internal/source-lints/empty-jsvalue-laundering.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `internal/source-lints/expect-call-counter.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `internal/source-lints/fn-long-mut-reborrow.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `internal/source-lints/frozen-nonnull-reborrow.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `internal/source-lints/jsresult-swallow.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `internal/source-lints/lockfile-registry-only.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `internal/source-lints/no-iostream-include.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `internal/source-lints/port-era-markers.test.ts` |  | ✅7/0 | ✅7/0 | both-pass |  |
| `internal/source-lints/pre-port-identifiers.test.ts` |  | ✅17/0 | ✅17/0 | both-pass |  |
| `internal/source-lints/primordials-exports.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `internal/source-lints/redis-client-types.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `internal/source-lints/self-receiver-reclaim.test.ts` |  | ✅4/0 | ✅4/0 | both-pass |  |
| `internal/source-lints/shim-stdint-includes.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `internal/source-lints/unsafe-refcount-exports.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `internal/source-lints/unsound-erased-box.test.ts` |  | ✅3/0 | ✅3/0 | both-pass |  |
| `internal/source-lints/vm-thread-door.test.ts` |  | ✅47/0 | ✅47/0 | both-pass |  |
| `internal/source-lints/windows-sys-link-cfg.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |

## N-API（5 文件 / 5 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `napi/napi-value-ffi.test.ts` |  ⊘3+3 | ❌0/1 | ❌0/1 | both-fail | env-baseline |
| `napi/napi.test.ts` | 🔧ohos ⊘2+2 | ❌0/0 | ❌0/0 | both-fail | env-baseline |
| `napi/uv_stub.test.ts` | 🔧ohos | ❌0/1 | ⏰ | both-fail | env-baseline |
| `napi/napi-finalizer-delete-ref.test.ts` |  ⊘1+1 | ❌0/1 | ✅1/0 | A-only-fail |  |
| `napi/uv.test.ts` | 🔧ohos | ❌0/1 | ✅8/0 | A-only-fail |  |

## V8 C++ 兼容（1 文件 / 1 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `v8/v8.test.ts` |  ⊘7+7 | ❌0/0 | ✅0/0 | A-only-fail |  |

## 其他（48 文件 / 4 失败）

| 文件 | 改动 | A 轮 | B 轮 | 失败集合 | 根因簇 |
|---|---|---|---|---|---|
| `js/first_party/ws/ws.test.ts` |  | ✅48/0 | ❌47/1 | B-only-fail |  |
| `js/workerd/html-rewriter.test.js` |  ⊘1+1 | ✅172/0 | ❌171/1 | B-only-fail |  |
| `js/valkey/reliability/connection-failures.test.ts` |  ⊘11+11 | ❌37/9⊘13 | ❌37/9⊘13 | both-fail | env-baseline |
| `js/valkey/valkey-tls-verify.test.ts` |  ⊘2+2 | ❌6/1 | ❌6/1 | both-fail | env-baseline |
| `config/bunfig/bunfig-errors.test.ts` |  | ✅5/0 | ✅5/0 | both-pass |  |
| `config/bunfig/preload.test.ts` |  ⊘2+2 | ✅18/0⊘2 | ✅18/0⊘2 | both-pass |  |
| `js/deno/abort/abort-controller.test.ts` |  | ✅6/0 | ✅6/0 | both-pass |  |
| `js/deno/crypto/random.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/deno/crypto/webcrypto.test.ts` |  | ✅37/0⊘3 | ✅37/0⊘3 | both-pass |  |
| `js/deno/encoding/encoding.test.ts` |  | ✅21/0⊘2 | ✅21/0⊘2 | both-pass |  |
| `js/deno/event/custom-event.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/deno/event/event-target.test.ts` |  | ✅14/0⊘1 | ✅14/0⊘1 | both-pass |  |
| `js/deno/event/event.test.ts` |  | ✅8/0⊘2 | ✅8/0⊘2 | both-pass |  |
| `js/deno/fetch/blob.test.ts` |  | ✅9/0⊘1 | ✅9/0⊘1 | both-pass |  |
| `js/deno/fetch/body.test.ts` |  | ✅3/0⊘2 | ✅3/0⊘2 | both-pass |  |
| `js/deno/fetch/headers.test.ts` |  | ✅26/0⊘1 | ✅26/0⊘1 | both-pass |  |
| `js/deno/fetch/request.test.ts` |  | ✅5/0⊘2 | ✅5/0⊘2 | both-pass |  |
| `js/deno/fetch/response.test.ts` |  | ✅8/0⊘1 | ✅8/0⊘1 | both-pass |  |
| `js/deno/performance/performance.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `js/deno/url/url.test.ts` |  | ✅33/0 | ✅33/0 | both-pass |  |
| `js/deno/url/urlsearchparams.test.ts` |  | ✅32/0 | ✅32/0 | both-pass |  |
| `js/deno/v8/error.test.ts` |  | ✅0/0⊘2 | ✅0/0⊘2 | both-pass |  |
| `js/first_party/undici/undici-primordials.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/first_party/undici/undici.test.ts` |  | ✅10/0 | ✅10/0 | both-pass |  |
| `js/first_party/utf-8-validate/utf-8-validate.test.ts` |  | ✅1/0 | ✅1/0 | both-pass |  |
| `js/first_party/ws/ws-proxy.test.ts` |  | ✅19/0 | ✅19/0 | both-pass |  |
| `js/first_party/ws/ws-syscall-fault.test.ts` |  ⊘1+1 | ✅0/0⊘3 | ✅0/0⊘3 | both-pass |  |
| `js/first_party/ws/ws-upgrade-events.test.ts` |  | ✅13/0 | ✅13/0 | both-pass |  |
| `js/junit-reporter/junit.test.js` |  ⊘4+4 | ✅8/0 | ✅8/0 | both-pass |  |
| `js/valkey/integration/complex-operations.test.ts` |  ⊘1+1 | ✅0/0⊘10 | ✅0/0⊘10 | both-pass |  |
| `js/valkey/reliability/error-handling.test.ts` |  ⊘1+1 | ✅0/0⊘55 | ✅0/0⊘55 | both-pass |  |
| `js/valkey/reliability/protocol-handling.test.ts` |  ⊘1+1 | ✅0/0⊘15 | ✅0/0⊘15 | both-pass |  |
| `js/valkey/reliability/recovery.test.ts` |  ⊘1+1 | ✅0/0⊘2 | ✅0/0⊘2 | both-pass |  |
| `js/valkey/reliability/resp-nesting-depth.test.ts` |  | ✅8/0 | ✅8/0 | both-pass |  |
| `js/valkey/unit/basic-operations.test.ts` |  ⊘1+1 | ✅0/0⊘20 | ✅0/0⊘20 | both-pass |  |
| `js/valkey/unit/buffer-operations.test.ts` |  ⊘1+1 | ✅0/0⊘9 | ✅0/0⊘9 | both-pass |  |
| `js/valkey/unit/hash-operations.test.ts` |  ⊘1+1 | ✅0/0⊘14 | ✅0/0⊘14 | both-pass |  |
| `js/valkey/unit/list-operations.test.ts` |  ⊘2+2 | ✅0/0⊘14 | ✅0/0⊘14 | both-pass |  |
| `js/valkey/unit/ping.test.ts` |  ⊘1+1 | ✅0/0⊘3 | ✅0/0⊘3 | both-pass |  |
| `js/valkey/valkey-gc.test.ts` |  ⊘1+1 | ✅10/0⊘8 | ✅10/0⊘8 | both-pass |  |
| `js/valkey/valkey-incremental-scan.test.ts` |  | ✅41/0 | ✅41/0 | both-pass |  |
| `js/valkey/valkey.test.ts` |  ⊘2+2 | ✅61/0⊘992 | ✅61/0⊘992 | both-pass |  |
| `js/workerd/html-rewriter-end-error.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `js/workerd/html-rewriter-leak.test.ts` |  ⊘2+2 | ✅12/0⊘1 | ✅12/0⊘1 | both-pass |  |
| `package-json-lint.test.ts` |  | ✅21/0 | ✅21/0 | both-pass |  |
| `regression/brotli-reset-leak.test.ts` |  | ✅2/0 | ✅2/0 | both-pass |  |
| `regression/issue23966.test.ts` |  | ✅20/0 | ✅20/0 | both-pass |  |
| `snippets/segfault-todo.test.js` |  | ✅1/0 | ✅1/0 | both-pass |  |

---
*共 2001 个执行单元。生成：2026-09-11。数据源：设备两轮日志（T2 解析）+ fork 树改动台账（T4）。逐用例版（62,397 行）随 T5→T7 交付。*
